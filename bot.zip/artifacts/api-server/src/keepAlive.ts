import type { Express } from "express";

export function keepAlive(app: Express): void {
  app.get("/api/keep-alive", (_request, response) => {
    response.status(200).type("text/plain").send("Aidea Discord bot is alive.");
  });
}