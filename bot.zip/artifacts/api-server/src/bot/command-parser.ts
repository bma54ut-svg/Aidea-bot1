export interface ParsedPrefixCommand {
  command: string;
  argumentText: string;
}

export interface ParsedNamedArguments {
  options: Record<string, string>;
  positionalText: string;
}

export function parsePrefixCommand(
  content: string,
  prefix = "*",
): ParsedPrefixCommand | undefined {
  const normalized = content.trimStart();
  if (!normalized.startsWith(prefix)) return undefined;

  const body = normalized.slice(prefix.length).trim();
  if (!body) return undefined;

  const firstWhitespace = body.search(/\s/);
  if (firstWhitespace < 0) {
    return { command: body.toLowerCase(), argumentText: "" };
  }

  return {
    command: body.slice(0, firstWhitespace).toLowerCase(),
    argumentText: body.slice(firstWhitespace).trim(),
  };
}

export function parseNamedArguments(input: string): ParsedNamedArguments {
  const options: Record<string, string> = {};
  const positionalText = input
    .replace(
      /([a-z][a-z0-9_-]*)=(?:"([^"]*)"|'([^']*)'|(\S+))/gi,
      (_match, key: string, doubleQuoted?: string, singleQuoted?: string, plain?: string) => {
        options[key.toLowerCase()] =
          doubleQuoted ?? singleQuoted ?? plain ?? "";
        return " ";
      },
    )
    .trim();

  return { options, positionalText };
}