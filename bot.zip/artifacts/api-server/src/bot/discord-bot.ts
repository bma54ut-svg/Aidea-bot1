import {
  ActionRowBuilder,
  AttachmentBuilder,
  ApplicationCommandOptionType,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  MessageFlags,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  type ApplicationCommandData,
  type ButtonInteraction,
  type ChatInputCommandInteraction,
  type Guild,
  type Message,
  type StringSelectMenuInteraction,
} from "discord.js";
import { randomInt } from "node:crypto";
import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { logger } from "../lib/logger";
import {
  choosePalette,
  type PaletteColor,
} from "./colors";
import {
  ChallengeCycleStore,
  NoIdeasInCategoryError,
  type SelectedIdea,
} from "./challenge-cycle";
import {
  characterOutfitIllustrations,
  characterTraitDefinitions,
  createCharacterProfile,
  type CharacterSelections,
} from "./character-generator";
import {
  BotFeatureStore,
  type CommunityIdea,
  type IdeaSuggestion,
  type IdeaVote,
} from "./feature-store";
import {
  challengeCategories,
  drawingIdeas,
  type ChallengeCategoryId,
} from "./ideas";
import {
  getPoseReference,
  getPoseReferenceById,
  poseReferences,
} from "./poses";
import { parseNamedArguments, parsePrefixCommand } from "./command-parser";

const poseAssetsDirectory = resolve(
  dirname(fileURLToPath(import.meta.url)),
  "../assets/poses",
);
const outfitAssetsDirectory = resolve(
  dirname(fileURLToPath(import.meta.url)),
  "../assets/outfits",
);

const challengeFocusDetails = {
  composition: {
    name: "التكوين",
    guidance: "رتّب العناصر بثلاث كتل واضحة، وحدّد نقطة جذب واحدة قبل التفاصيل.",
  },
  perspective: {
    name: "المنظور",
    guidance: "اختر مستوى نظر واضحاً وأظهر اختلاف الحجم بين القريب والبعيد.",
  },
  gesture: {
    name: "الحركة",
    guidance: "ابدأ بخط حركة واحد، ثم ابنِ حوله الكتفين والحوض والأطراف.",
  },
  silhouette: {
    name: "الهيئة الخارجية",
    guidance: "اجعل الشكل مقروءاً كظل أسود قبل إضافة الوجه والملابس.",
  },
  lighting: {
    name: "الضوء والظل",
    guidance: "حدّد مصدر ضوء واحداً وارسم الظلال باتجاه متّسق.",
  },
  materials: {
    name: "الخامات",
    guidance: "أظهر فرقاً بين خامتين باستخدام حواف وتظليل وملمس مختلف.",
  },
  storytelling: {
    name: "السرد البصري",
    guidance: "أضف تفصيلاً صغيراً يشرح ما حدث قبل لحظة الرسم.",
  },
  color: {
    name: "تناغم الألوان",
    guidance: "اختر لوناً مهيمناً ولوناً مساعداً ولمسة صغيرة تلفت النظر.",
  },
} as const;

const challengeFormatDetails = {
  character: {
    name: "تصميم شخصية",
    guidance: "أظهر الهيئة كاملة مع غرض أو تفصيل يوضح دور الشخصية.",
  },
  portrait: {
    name: "بورتريه قريب",
    guidance: "قرّب الكادر واجعل التعبير والإضاءة أساس الصورة.",
  },
  wide_scene: {
    name: "مشهد واسع",
    guidance: "قسّم المشهد إلى مقدمة ووسط وخلفية حتى يظهر العمق.",
  },
  prop_sheet: {
    name: "ورقة أغراض",
    guidance: "ارسم الغرض من ثلاث زوايا وأضف تفصيلاً يشرح استخدامه.",
  },
  poster: {
    name: "ملصق",
    guidance: "استخدم شكلاً رئيسياً واضحاً واترك مساحة مريحة حوله.",
  },
  three_moments: {
    name: "ثلاث لقطات",
    guidance: "قسّم الفكرة إلى بداية ولحظة تغيير ونتيجة.",
  },
} as const;

const challengeCommand: ApplicationCommandData = {
  name: "challenge",
  description: "احصل على تحدّي رسم قابل للتخصيص",
  options: [
    {
      type: ApplicationCommandOptionType.String,
      name: "theme",
      description: "اختيار فئة الفكرة (اختياري)",
      required: false,
      choices: challengeCategories.map(({ id, name }) => ({
        name,
        value: id,
      })),
    },
    {
      type: ApplicationCommandOptionType.String,
      name: "difficulty",
      description: "مستوى التحدّي (اختياري)",
      required: false,
      choices: [
        { name: "بسيط", value: "easy" },
        { name: "متوسط", value: "medium" },
        { name: "متقدّم", value: "advanced" },
      ],
    },
    {
      type: ApplicationCommandOptionType.Integer,
      name: "duration",
      description: "الوقت المقترح بالدقائق (اختياري)",
      required: false,
      choices: [
        { name: "١٥ دقيقة", value: 15 },
        { name: "٣٠ دقيقة", value: 30 },
        { name: "٦٠ دقيقة", value: 60 },
      ],
    },
    {
      type: ApplicationCommandOptionType.Boolean,
      name: "colors",
      description: "أضف لوحة ألوان عشوائية من ٢ إلى ٤ ألوان",
      required: false,
    },
    {
      type: ApplicationCommandOptionType.String,
      name: "style",
      description: "أسلوب الرسم المقترح",
      required: false,
      choices: [
        { name: "أنمي بخطوط نظيفة", value: "anime" },
        { name: "ألوان مائية ناعمة", value: "watercolor" },
        { name: "قصص مصورة وتظليل قوي", value: "comic" },
        { name: "رسم رصاص وخطوط بناء", value: "pencil" },
        { name: "كرتوني مبسّط", value: "cartoon" },
        { name: "واقعي بإضاءة سينمائية", value: "cinematic" },
      ],
    },
    {
      type: ApplicationCommandOptionType.String,
      name: "twist",
      description: "قيد إبداعي إضافي للتحدّي",
      required: false,
      choices: [
        { name: "استخدم لونين فقط", value: "two-colors" },
        { name: "منظور من زاوية منخفضة", value: "low-angle" },
        { name: "أظهر الشخصية من الخلف", value: "back-view" },
        { name: "أضف انعكاساً في المشهد", value: "reflection" },
        { name: "اجعل الظل يحكي شيئاً مختلفاً", value: "story-shadow" },
        { name: "ارسم المشهد داخل إطار غير مألوف", value: "unusual-frame" },
        { name: "لا تستخدم خطوطاً مستقيمة", value: "no-straight-lines" },
      ],
    },
    {
      type: ApplicationCommandOptionType.String,
      name: "focus",
      description: "المهارة الفنية التي تريد التدرب عليها",
      required: false,
      choices: Object.entries(challengeFocusDetails).map(([value, detail]) => ({
        name: detail.name,
        value,
      })),
    },
    {
      type: ApplicationCommandOptionType.String,
      name: "format",
      description: "طريقة عرض الفكرة أو تقسيمها",
      required: false,
      choices: Object.entries(challengeFormatDetails).map(([value, detail]) => ({
        name: detail.name,
        value,
      })),
    },
  ],
};

const helpCommand: ApplicationCommandData = {
  name: "help",
  description: "شرح أوامر بوت تحدّي الرسم",
};

const formCommand: ApplicationCommandData = {
  name: "form",
  description: "كوّن شخصية كاملة للرسم",
  options: characterTraitDefinitions.map((trait) => ({
    type: ApplicationCommandOptionType.String,
    name: trait.id,
    description: trait.description,
    required: false,
    // Discord permits up to 25 static choices; the pose picker button exposes all poses.
    choices: trait.choices.slice(0, 25).map((choice) => ({
      name: choice,
      value: choice,
    })),
  })),
};

const poseGalleryCommand: ApplicationCommandData = {
  name: "poses",
  description: "تصفّح بوزات مرسومة وافتح وصف كل بوز",
};

const suggestCommand: ApplicationCommandData = {
  name: "suggest",
  description: "اقترح فكرة رسم جديدة للمجتمع",
  options: [
    {
      type: ApplicationCommandOptionType.String,
      name: "prompt",
      description: "وصف فكرة الرسم، من ١٠ إلى ٣٠٠ حرف",
      required: true,
    },
    {
      type: ApplicationCommandOptionType.String,
      name: "theme",
      description: "الفئة التي تناسب الفكرة",
      required: false,
      choices: challengeCategories.map(({ id, name }) => ({
        name,
        value: id,
      })),
    },
  ],
};

const reviewCommand: ApplicationCommandData = {
  name: "review",
  description: "راجع أول فكرة رسم مقترحة من أعضاء السيرفر",
  defaultMemberPermissions: PermissionFlagsBits.ManageGuild,
};

const communityCommand: ApplicationCommandData = {
  name: "community",
  description: "اعرض فكرة رسم اقترحها مجتمع السيرفر وصوّت عليها",
};

const dailyCommand: ApplicationCommandData = {
  name: "daily",
  description: "إعداد أو إيقاف تحدّي الرسم اليومي",
  options: [
    {
      type: ApplicationCommandOptionType.Subcommand,
      name: "set",
      description: "انشر تحدّياً يومياً في قناة بوقت تختاره",
      options: [
        {
          type: ApplicationCommandOptionType.Channel,
          name: "channel",
          description: "القناة التي ستستقبل التحدّي",
          required: true,
          channelTypes: [ChannelType.GuildText, ChannelType.GuildAnnouncement],
        },
        {
          type: ApplicationCommandOptionType.String,
          name: "time",
          description: "وقت النشر بصيغة 24 ساعة، مثل 18:30",
          required: true,
        },
        {
          type: ApplicationCommandOptionType.String,
          name: "timezone",
          description: "المنطقة الزمنية، مثل Asia/Baghdad",
          required: true,
        },
      ],
    },
    {
      type: ApplicationCommandOptionType.Subcommand,
      name: "off",
      description: "أوقف النشر اليومي في هذا السيرفر",
    },
  ],
};

const commandDefinitions = [
  challengeCommand,
  helpCommand,
  formCommand,
  poseGalleryCommand,
  suggestCommand,
  reviewCommand,
  communityCommand,
  dailyCommand,
];
const challengeButtonIds = {
  next: "aidea:next",
  colors: "aidea:colors",
  remix: "aidea:remix",
} as const;
const challengeCategoryMenuId = "aidea:challenge:category";
const posePageButtonIds = {
  previous: "aidea:poses:previous",
  next: "aidea:poses:next",
} as const;
const characterButtonIds = {
  reroll: "aidea:form:reroll",
} as const;
const poseMenuIds = {
  gallery: "aidea:poses:select",
} as const;
const communityButtonIds = {
  next: "aidea:community:next",
  up: "aidea:community:up",
  down: "aidea:community:down",
} as const;
const ideaReviewButtonPrefix = "aidea:review:";

const difficultyDetails = {
  easy: {
    name: "بسيط",
    guidance: "ركّز على الأشكال الكبيرة وتكوين المشهد.",
  },
  medium: {
    name: "متوسط",
    guidance: "اهتم بالضوء والظل وتوزيع التفاصيل.",
  },
  advanced: {
    name: "متقدّم",
    guidance: "جرّب منظوراً واضحاً وإضاءة مركبة وتفاصيل دقيقة.",
  },
} as const;

type Difficulty = keyof typeof difficultyDetails;

const challengeStyles = {
  anime: "أنمي بخطوط نظيفة",
  watercolor: "ألوان مائية ناعمة",
  comic: "قصص مصورة وتظليل قوي",
  pencil: "رسم رصاص وخطوط بناء",
  cartoon: "كرتوني مبسّط",
  cinematic: "واقعي بإضاءة سينمائية",
} as const;

type ChallengeStyle = keyof typeof challengeStyles;

const challengeTwists = {
  "two-colors": "استخدم لونين فقط",
  "low-angle": "منظور من زاوية منخفضة",
  "back-view": "أظهر الشخصية من الخلف",
  reflection: "أضف انعكاساً في المشهد",
  "story-shadow": "اجعل الظل يحكي شيئاً مختلفاً",
  "unusual-frame": "ارسم المشهد داخل إطار غير مألوف",
  "no-straight-lines": "لا تستخدم خطوطاً مستقيمة",
} as const;

type ChallengeTwist = keyof typeof challengeTwists;
type ChallengeFocus = keyof typeof challengeFocusDetails;
type ChallengeFormat = keyof typeof challengeFormatDetails;

function randomRecordKey<T extends object>(record: T): keyof T {
  const keys = Object.keys(record) as Array<keyof T>;
  return keys[randomInt(keys.length)]!;
}

interface ChallengeSession {
  ownerId: string;
  guildId: string;
  currentIdeaId: string;
  categoryId?: ChallengeCategoryId;
  difficulty?: Difficulty;
  duration?: number;
  colors?: PaletteColor[];
  style?: ChallengeStyle;
  twist?: ChallengeTwist;
  focus?: ChallengeFocus;
  format?: ChallengeFormat;
}

interface PrefixChallengeOptions {
  difficulty?: Difficulty;
  duration?: number;
  includeColors: boolean;
  style?: ChallengeStyle;
  twist?: ChallengeTwist;
  focus?: ChallengeFocus;
  format?: ChallengeFormat;
}

interface PendingChallengeCategorySession {
  ownerId: string;
  guildId: string;
  options: PrefixChallengeOptions;
  processing?: boolean;
}

interface CharacterSession {
  ownerId: string;
  selections: CharacterSelections;
}

interface CommunitySession {
  guildId: string;
  ideaId: string;
}

interface PoseGallerySession {
  ownerId: string;
  page: number;
}

const challengeSessions = new Map<string, ChallengeSession>();
const pendingChallengeCategorySessions = new Map<
  string,
  PendingChallengeCategorySession
>();
const characterSessions = new Map<string, CharacterSession>();
const communitySessions = new Map<string, CommunitySession>();
const poseGallerySessions = new Map<string, PoseGallerySession>();
const maxChallengeSessions = 2_000;

function challengeButtons() {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(challengeButtonIds.next)
      .setLabel("فكرة ثانية")
      .setEmoji("🎲")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(challengeButtonIds.colors)
      .setLabel("ألوان عشوائية")
      .setEmoji("🎨")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(challengeButtonIds.remix)
      .setLabel("تفاصيل جديدة")
      .setEmoji("✨")
      .setStyle(ButtonStyle.Secondary),
  );
}

function challengeCategoryRow() {
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(challengeCategoryMenuId)
      .setPlaceholder("اختار فئة التحدّي")
      .addOptions(
        {
          label: "اختيار عشوائي",
          value: "random",
          description: "خلّي البوت يختار فئة مختلفة لك",
        },
        ...challengeCategories.map(({ id, name }) => ({
          label: name,
          value: id,
          description: `أفكار رسم من فئة ${name}`.slice(0, 100),
        })),
      ),
  );
}

function characterButtons() {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(characterButtonIds.reroll)
      .setLabel("شخصية ثانية")
      .setEmoji("🎲")
      .setStyle(ButtonStyle.Primary),
  );
}

const posesPerGalleryPage = 8;

function poseSelectRow(
  customId: string = poseMenuIds.gallery,
  page = 0,
  pageSize = posesPerGalleryPage,
) {
  const start = page * pageSize;
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder("اختار بوز حتى تشوف الرسم والتفاصيل")
      .addOptions(
        poseReferences.slice(start, start + pageSize).map((pose) => ({
          label: pose.label,
          value: pose.id,
          description: `${pose.category} — ${pose.drawingTip}`.slice(0, 100),
        })),
      ),
  );
}

function poseGalleryPageCount(): number {
  return Math.ceil(poseReferences.length / posesPerGalleryPage);
}

function poseGalleryPageEmbeds(page: number): EmbedBuilder[] {
  const start = page * posesPerGalleryPage;
  return poseReferences
    .slice(start, start + posesPerGalleryPage)
    .map((pose) =>
      new EmbedBuilder()
        .setTitle(pose.label)
        .setDescription(`${pose.category} · ${pose.drawingTip}`)
        .setColor(0x7656c9)
        .setImage(`attachment://${pose.imageFile}`),
    );
}

function poseGalleryComponents(page: number) {
  const totalPages = poseGalleryPageCount();
  const pageRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(posePageButtonIds.previous)
      .setLabel("السابق")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page <= 0),
    new ButtonBuilder()
      .setCustomId(posePageButtonIds.next)
      .setLabel("التالي")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= totalPages - 1),
  );
  return [
    poseSelectRow(poseMenuIds.gallery, page, posesPerGalleryPage),
    pageRow,
  ];
}

function poseAttachment(label: string): AttachmentBuilder {
  const pose = getPoseReference(label);
  if (!pose) throw new Error(`No pose reference exists for "${label}".`);
  const filePath = resolve(poseAssetsDirectory, pose.imageFile);
  if (!existsSync(filePath)) {
    throw new Error(`The pose reference image is missing: ${pose.imageFile}`);
  }
  return new AttachmentBuilder(filePath, { name: pose.imageFile });
}

function outfitAttachment(
  outfit: (typeof characterOutfitIllustrations)[number],
): AttachmentBuilder {
  const filePath = resolve(outfitAssetsDirectory, outfit.imageFile);
  if (!existsSync(filePath)) {
    throw new Error(`The outfit reference image is missing: ${outfit.imageFile}`);
  }
  return new AttachmentBuilder(filePath, { name: outfit.imageFile });
}

function poseEmbed(pose: (typeof poseReferences)[number]) {
  return new EmbedBuilder()
    .setTitle(pose.label)
    .setDescription(pose.description)
    .setColor(0x7656c9)
    .addFields(
      { name: "نوع الحركة", value: pose.category, inline: true },
      { name: "ملاحظة للرسم", value: pose.drawingTip },
    )
    .setImage(`attachment://${pose.imageFile}`)
    .setFooter({ text: "Aidea — غيّر اتجاه الحركة أو زاوية الكاميرا بطريقتك." });
}

function communityButtons(disabled = false) {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(communityButtonIds.up)
      .setLabel("تعجبني")
      .setEmoji("👍")
      .setStyle(ButtonStyle.Success)
      .setDisabled(disabled),
    new ButtonBuilder()
      .setCustomId(communityButtonIds.down)
      .setLabel("مو مناسبة")
      .setEmoji("👎")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(disabled),
    new ButtonBuilder()
      .setCustomId(communityButtonIds.next)
      .setLabel("فكرة ثانية")
      .setEmoji("🎲")
      .setStyle(ButtonStyle.Primary),
  );
}

function saveChallengeSession(messageId: string, session: ChallengeSession) {
  if (challengeSessions.size >= maxChallengeSessions) {
    const oldestMessageId = challengeSessions.keys().next().value;
    if (oldestMessageId) challengeSessions.delete(oldestMessageId);
  }
  challengeSessions.set(messageId, session);
}

function saveCharacterSession(messageId: string, session: CharacterSession) {
  if (characterSessions.size >= maxChallengeSessions) {
    const oldestMessageId = characterSessions.keys().next().value;
    if (oldestMessageId) characterSessions.delete(oldestMessageId);
  }
  characterSessions.set(messageId, session);
}

function saveCommunitySession(messageId: string, session: CommunitySession) {
  if (communitySessions.size >= maxChallengeSessions) {
    const oldestMessageId = communitySessions.keys().next().value;
    if (oldestMessageId) communitySessions.delete(oldestMessageId);
  }
  communitySessions.set(messageId, session);
}

function challengeEmbed(
  idea: SelectedIdea,
  options: {
    difficulty?: Difficulty;
    duration?: number;
    colors?: PaletteColor[];
    style?: ChallengeStyle;
    twist?: ChallengeTwist;
    focus?: ChallengeFocus;
    format?: ChallengeFormat;
  },
) {
  const category = challengeCategories.find(
    ({ id }) => id === idea.category,
  );
  const embed = new EmbedBuilder()
    .setTitle("تحدّي الرسم")
    .setDescription(idea.prompt)
    .setFooter({ text: "Aidea — ارسم بطريقتك واستمتع بالتحدّي." })
    .addFields({
      name: "الفئة",
      value: category?.name ?? "متنوع",
      inline: true,
    });

  if (options.difficulty) {
    const difficulty = difficultyDetails[options.difficulty];
    embed.addFields({
      name: `المستوى: ${difficulty.name}`,
      value: difficulty.guidance,
      inline: true,
    });
  }

  if (options.duration) {
    embed.addFields({
      name: "وقت مقترح",
      value: `${options.duration} دقيقة`,
      inline: true,
    });
  }

  if (options.style) {
    embed.addFields({
      name: "أسلوب الرسم",
      value: challengeStyles[options.style],
      inline: true,
    });
  }

  if (options.twist) {
    embed.addFields({
      name: "قيد إبداعي",
      value: challengeTwists[options.twist],
      inline: true,
    });
  }

  if (options.focus) {
    const focus = challengeFocusDetails[options.focus];
    embed.addFields({
      name: `تمرين: ${focus.name}`,
      value: focus.guidance,
      inline: true,
    });
  }

  if (options.format) {
    const format = challengeFormatDetails[options.format];
    embed.addFields({
      name: `صيغة: ${format.name}`,
      value: format.guidance,
      inline: true,
    });
  }

  if (options.colors?.length) {
    embed.setColor(Number.parseInt(options.colors[0]!.hex.slice(1), 16));
    const colorLines = options.colors
      .map(({ name, hex }) => `• **${name}** — \`${hex}\``)
      .join("\n");

    embed.addFields({
      name: "لوحة ألوان اختيارية",
      value:
        `${colorLines}\n\n` +
        "استخدم الأكواد للرسم الرقمي أو أسماء الألوان للرسم التقليدي.",
    });
  }

  return embed;
}

function characterEmbed(profile: ReturnType<typeof createCharacterProfile>) {
  const embed = new EmbedBuilder()
    .setTitle("شخصية جديدة للرسم")
    .setDescription("مواصفات متنوعة وجاهزة للرسم.")
    .setColor(0x7656c9)
    .addFields(
      {
        name: "الشعر",
        value: `${profile.hair} — ${profile.hair_color}`,
        inline: true,
      },
      { name: "العينان", value: `${profile.eyes} — ${profile.expression}`, inline: true },
      { name: "ملامح الوجه", value: profile.features, inline: true },
      { name: "لون البشرة", value: profile.skin_tone, inline: true },
      { name: "بنية الجسم", value: profile.build, inline: true },
      { name: "الملابس", value: profile.outfit, inline: true },
      { name: "حركة اليدين", value: profile.gesture, inline: true },
      { name: "الإكسسوارات", value: profile.accessories, inline: true },
      { name: "غرض يحمله", value: profile.character_prop, inline: true },
      { name: "الإضاءة والجو", value: profile.lighting, inline: true },
      { name: "أسلوب الرسم", value: profile.art_style, inline: true },
      { name: "العلامة المميزة", value: profile.signature_detail, inline: true },
      { name: "اللون البارز", value: profile.accent_color, inline: true },
    )
    .setFooter({ text: "استخدم *form لشخصية ثانية أو *poses لمعرض البوزات." });

  return embed;
}

function characterImagePayload(
  profile: ReturnType<typeof createCharacterProfile>,
) {
  const pose = poseReferences[randomInt(poseReferences.length)]!;
  const outfit = characterOutfitIllustrations.find(
    ({ label }) => label === profile.outfit,
  );
  if (!outfit) {
    throw new Error(`No outfit reference image exists for "${profile.outfit}".`);
  }

  return {
    embeds: [
      characterEmbed(profile),
      new EmbedBuilder()
        .setTitle("مرجع البوز")
        .setColor(0x7656c9)
        .setImage(`attachment://${pose.imageFile}`),
      new EmbedBuilder()
        .setTitle("مرجع الملابس")
        .setColor(0x7656c9)
        .setImage(`attachment://${outfit.imageFile}`),
    ],
    files: [poseAttachment(pose.label), outfitAttachment(outfit)],
  };
}

function ideaSuggestionEmbed(suggestion: IdeaSuggestion) {
  const category = challengeCategories.find(
    ({ id }) => id === suggestion.category,
  );
  return new EmbedBuilder()
    .setTitle("فكرة جديدة بانتظار المراجعة")
    .setDescription(suggestion.prompt)
    .setColor(0xe8a044)
    .addFields(
      { name: "الفئة", value: category?.name ?? "متنوعة", inline: true },
      { name: "صاحب الفكرة", value: `<@${suggestion.authorId}>`, inline: true },
    )
    .setFooter({ text: "راجع المحتوى قبل اعتماده ليظهر في أفكار المجتمع." });
}

function ideaReviewButtons(suggestionId: string) {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`${ideaReviewButtonPrefix}approve:${suggestionId}`)
      .setLabel("اعتماد الفكرة")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`${ideaReviewButtonPrefix}reject:${suggestionId}`)
      .setLabel("رفض")
      .setStyle(ButtonStyle.Danger),
  );
}

function communityIdeaEmbed(idea: CommunityIdea, featureStore: BotFeatureStore) {
  const category = challengeCategories.find(
    ({ id }) => id === idea.category,
  );
  const votes = featureStore.getVoteCounts(idea.id);
  const embed = new EmbedBuilder()
    .setTitle(votes.removed ? "فكرة أُرشفت بتصويت المجتمع" : "فكرة من المجتمع")
    .setDescription(idea.prompt)
    .setColor(votes.removed ? 0x777777 : 0x3b9b83)
    .addFields(
      { name: "الفئة", value: category?.name ?? "متنوعة", inline: true },
      { name: "التقييم", value: `👍 ${votes.up}  ·  👎 ${votes.down}`, inline: true },
    )
    .setFooter({
      text: votes.removed
        ? "هذه الفكرة أُرشفت بعد حصولها على ١٠ أصوات سلبية."
        : "صوّت للفكرة أو اعرض فكرة مجتمعية ثانية.",
    });

  return embed;
}

function getLocalDateAndTime(
  timeZone: string,
  date = new Date(),
): { date: string; time: string } {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  const value = (type: string) => parts.find((part) => part.type === type)?.value;
  const year = value("year");
  const month = value("month");
  const day = value("day");
  const hour = value("hour");
  const minute = value("minute");
  if (!year || !month || !day || !hour || !minute) {
    throw new Error(`Could not read local date/time for "${timeZone}".`);
  }
  return { date: `${year}-${month}-${day}`, time: `${hour}:${minute}` };
}

function helpEmbed() {
  const categories = challengeCategories
    .map(({ id, name }) => `• \`${id}\` — ${name}`)
    .join("\n");

  return new EmbedBuilder()
    .setTitle("مساعدة تحدّي الرسم")
    .setDescription(
      "اكتب الأمر في القناة مع بادئة النجمة `*`، مثل `*challenge` أو `*help`.",
    )
    .addFields(
      {
        name: "الرسم والشخصيات",
        value:
          "• `*challenge` — يفتح قائمة لاختيار فئة التحدّي.\n" +
          "• `*form` — يكوّن شخصية؛ يمكن تحديد الخيارات بصيغة `hair=\"كيرلي كثيف\"`.\n" +
          "• `*poses` — يعرض البوزات المرجعية المرسومة.\n" +
          "• `*community` — يعرض فكرة من اقتراحات الأعضاء.\n" +
          "• `*help` — يعرض هذه المساعدة.",
      },
      {
        name: "تخصيص التحدّي",
        value:
          "اكتب `*challenge` لاختيار الفئة من القائمة، أو حدّدها يدوياً: `*challenge theme=animals difficulty=medium duration=30 colors style=anime`.\n" +
          "الخيارات: `theme`, `difficulty`, `duration`, `colors`, `style`, `twist`, `focus`, `format`.",
      },
      {
        name: "الفئات",
        value: `اختارها من القائمة بعد \`*challenge\`، أو استخدم الرمز:\n${categories}`,
      },
      {
        name: "أفكار المجتمع",
        value:
          "• `*suggest theme=animals prompt=\"فكرة الرسم\"` — اقترح فكرة.\n" +
          "• `*review` — للمشرفين لمراجعة الأفكار.\n" +
          "• `*community` — استعرض الأفكار المعتمدة وصوّت لها.\n" +
          "• `*daily set #القناة 18:30 Asia/Baghdad` — جدولة تحدّي يومي.\n" +
          "• `*daily off` — إيقاف التحدّي اليومي.",
      },
      {
        name: "تكرار الأفكار",
        value:
          "لا تتكرر الأفكار داخل دورة السيرفر. عند نفاد أفكار فئة محددة، اختر فئة أخرى أو اترك `theme` فارغاً.",
      },
      {
        name: "تكوين الشخصيات",
        value:
          "يمكن ضبط الخيارات بصيغة `اسم_الخيار=\"القيمة\"`. اترك الخيار فارغاً ليختاره البوت عشوائياً؛ وتظهر صورة البوز داخل بطاقة الشخصية.",
      },
    )
    .setFooter({ text: "الأكواد اللونية إرشادية وليست إلزامية." });
}

function getSelectedCategory(
  categoryValue: string | null,
): ChallengeCategoryId | undefined {
  return challengeCategories.find(({ id }) => id === categoryValue)?.id;
}

async function syncGuildSlashCommands(guild: Guild): Promise<void> {
  if (process.env["REGISTER_SLASH_COMMANDS"] === "false") {
    logger.info({ guildId: guild.id }, "Slash command registration is disabled");
    return;
  }
  await guild.commands.set(commandDefinitions);
  logger.info({ guildId: guild.id, count: commandDefinitions.length }, "Discord slash commands synchronized");
}

async function removeGuildSlashCommands(guild: Guild): Promise<void> {
  await guild.commands.set([]);
  logger.info({ guildId: guild.id }, "Discord slash commands removed");
}

async function sendChallenge(
  interaction: ChatInputCommandInteraction,
  store: ChallengeCycleStore,
): Promise<void> {
  if (!interaction.guildId) {
    await interaction.reply({
      content: "هذا الأمر متاح داخل السيرفرات فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const categoryId = getSelectedCategory(
    interaction.options.getString("theme"),
  );
  const difficultyValue = interaction.options.getString("difficulty");
  const difficulty =
    difficultyValue && difficultyValue in difficultyDetails
      ? (difficultyValue as Difficulty)
      : undefined;
  const duration = interaction.options.getInteger("duration") ?? undefined;
  const includeColors = interaction.options.getBoolean("colors") ?? false;
  const styleValue = interaction.options.getString("style");
  const style =
    styleValue && Object.hasOwn(challengeStyles, styleValue)
      ? (styleValue as ChallengeStyle)
      : undefined;
  const twistValue = interaction.options.getString("twist");
  const twist =
    twistValue && Object.hasOwn(challengeTwists, twistValue)
      ? (twistValue as ChallengeTwist)
      : undefined;
  const focusValue = interaction.options.getString("focus");
  const focus =
    focusValue && Object.hasOwn(challengeFocusDetails, focusValue)
      ? (focusValue as ChallengeFocus)
      : undefined;
  const formatValue = interaction.options.getString("format");
  const format =
    formatValue && Object.hasOwn(challengeFormatDetails, formatValue)
      ? (formatValue as ChallengeFormat)
      : undefined;

  await interaction.deferReply();

  const idea = await store.next(interaction.guildId, categoryId);
  const colors = includeColors ? choosePalette(randomInt(2, 5)) : undefined;
  const message = await interaction.editReply({
    embeds: [
      challengeEmbed(idea, {
        difficulty,
        duration,
        colors,
        style,
        twist,
        focus,
        format,
      }),
    ],
    components: [challengeButtons()],
  });

  saveChallengeSession(message.id, {
    ownerId: interaction.user.id,
    guildId: interaction.guildId,
    currentIdeaId: idea.id,
    ...(categoryId ? { categoryId } : {}),
    ...(difficulty ? { difficulty } : {}),
    ...(duration ? { duration } : {}),
    ...(colors ? { colors } : {}),
    ...(style ? { style } : {}),
    ...(twist ? { twist } : {}),
    ...(focus ? { focus } : {}),
    ...(format ? { format } : {}),
  });
}

async function sendCharacterForm(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const selections: CharacterSelections = {};
  for (const trait of characterTraitDefinitions) {
    const selected = interaction.options.getString(trait.id);
    if (selected !== null) {
      Object.assign(selections, { [trait.id]: selected });
    }
  }

  await interaction.deferReply();
  const profile = createCharacterProfile(selections);
  const characterImages = characterImagePayload(profile);
  const message = await interaction.editReply({
    ...characterImages,
    components: [characterButtons()],
  });

  saveCharacterSession(message.id, {
    ownerId: interaction.user.id,
    selections,
  });
}

async function sendPoseGallery(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const page = 0;
  const start = page * posesPerGalleryPage;
  const visiblePoses = poseReferences.slice(
    start,
    start + posesPerGalleryPage,
  );
  const response = await interaction.reply({
    content: `معرض البوزات — الصفحة ${page + 1} من ${poseGalleryPageCount()}. اختار بوزاً من القائمة لعرض الشرح الكامل.`,
    embeds: poseGalleryPageEmbeds(page),
    files: visiblePoses.map((pose) => poseAttachment(pose.label)),
    components: poseGalleryComponents(page),
    flags: MessageFlags.Ephemeral,
    withResponse: true,
  });
  const messageId =
    response.resource?.message?.id ?? (await interaction.fetchReply()).id;
  savePoseGallerySession(messageId, {
    ownerId: interaction.user.id,
    page,
  });
}

function savePoseGallerySession(messageId: string, session: PoseGallerySession) {
  if (poseGallerySessions.size >= maxChallengeSessions) {
    const oldestMessageId = poseGallerySessions.keys().next().value;
    if (oldestMessageId) poseGallerySessions.delete(oldestMessageId);
  }
  poseGallerySessions.set(messageId, session);
}

async function handlePosePageButton(
  interaction: ButtonInteraction,
): Promise<void> {
  const session = poseGallerySessions.get(interaction.message.id);
  if (!session) {
    await interaction.reply({
      content: "انتهت صلاحية المعرض. استخدم `*poses` لفتحه من جديد.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (interaction.user.id !== session.ownerId) {
    await interaction.reply({
      content: "التنقل في هذا المعرض متاح لمن فتحه فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const direction =
    interaction.customId === posePageButtonIds.next ? 1 : -1;
  const page = Math.max(
    0,
    Math.min(poseGalleryPageCount() - 1, session.page + direction),
  );
  const start = page * posesPerGalleryPage;
  const visiblePoses = poseReferences.slice(
    start,
    start + posesPerGalleryPage,
  );
  await interaction.update({
    content: `معرض البوزات — الصفحة ${page + 1} من ${poseGalleryPageCount()}. اختار بوزاً من القائمة لعرض الشرح الكامل.`,
    embeds: poseGalleryPageEmbeds(page),
    files: visiblePoses.map((pose) => poseAttachment(pose.label)),
    attachments: [],
    components: poseGalleryComponents(page),
  });
  poseGallerySessions.set(interaction.message.id, {
    ownerId: session.ownerId,
    page,
  });
}

async function sendIdeaSuggestion(
  interaction: ChatInputCommandInteraction,
  featureStore: BotFeatureStore,
): Promise<void> {
  if (!interaction.guildId) {
    await interaction.reply({
      content: "اقتراح الأفكار متاح داخل السيرفرات فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const prompt = interaction.options.getString("prompt", true);
  const category =
    getSelectedCategory(interaction.options.getString("theme")) ?? "community";
  const suggestion = await featureStore.submitIdea(
    interaction.guildId,
    prompt,
    category,
    interaction.user.id,
  );
  await interaction.reply({
    content:
      "وصل اقتراحك للمراجعة. إذا اعتمده مشرف السيرفر، راح يظهر ضمن أفكار المجتمع.",
    flags: MessageFlags.Ephemeral,
  });
  logger.info(
    { guildId: interaction.guildId, suggestionId: suggestion.id },
    "A community drawing idea was submitted",
  );
}

async function sendIdeaReview(
  interaction: ChatInputCommandInteraction,
  featureStore: BotFeatureStore,
): Promise<void> {
  if (!interaction.guildId) {
    await interaction.reply({
      content: "مراجعة الاقتراحات متاحة داخل السيرفرات فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    await interaction.reply({
      content: "هذا الأمر متاح لمشرفي السيرفر فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const suggestion = featureStore.listPendingIdeas(interaction.guildId, 1)[0];
  if (!suggestion) {
    await interaction.reply({
      content: "ماكو اقتراحات جديدة بانتظار المراجعة.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await interaction.reply({
    embeds: [ideaSuggestionEmbed(suggestion)],
    components: [ideaReviewButtons(suggestion.id)],
    flags: MessageFlags.Ephemeral,
  });
}

function chooseCommunityIdea(
  featureStore: BotFeatureStore,
  guildId: string,
  avoidIdeaId?: string,
): CommunityIdea | undefined {
  let candidates = featureStore
    .getApprovedIdeas(guildId)
    .filter(({ id }) => !featureStore.getRemovedIdeaIds().has(id));
  if (avoidIdeaId && candidates.length > 1) {
    candidates = candidates.filter(({ id }) => id !== avoidIdeaId);
  }
  if (candidates.length === 0) return undefined;
  return candidates[randomInt(candidates.length)];
}

async function sendCommunityIdea(
  interaction: ChatInputCommandInteraction,
  featureStore: BotFeatureStore,
): Promise<void> {
  if (!interaction.guildId) {
    await interaction.reply({
      content: "أفكار المجتمع متاحة داخل السيرفرات فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const idea = chooseCommunityIdea(featureStore, interaction.guildId);
  if (!idea) {
    await interaction.reply({
      content:
        "ماكو أفكار مجتمعية معتمدة بعد. استخدم `*suggest` حتى تقترح فكرة، وبعد مراجعتها تظهر هنا.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const message = await interaction.reply({
    embeds: [communityIdeaEmbed(idea, featureStore)],
    components: [communityButtons(featureStore.getVoteCounts(idea.id).removed)],
    withResponse: true,
  });
  const messageId = message.resource?.message?.id;
  if (messageId) saveCommunitySession(messageId, { guildId: interaction.guildId, ideaId: idea.id });
}

async function sendDailyConfiguration(
  interaction: ChatInputCommandInteraction,
  featureStore: BotFeatureStore,
): Promise<void> {
  if (!interaction.guildId) {
    await interaction.reply({
      content: "إعداد التحدّي اليومي متاح داخل السيرفرات فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    await interaction.reply({
      content: "إعداد التحدّي اليومي متاح لمشرفي السيرفر فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (interaction.options.getSubcommand() === "off") {
    await featureStore.disableDaily(interaction.guildId);
    await interaction.reply({
      content: "تم إيقاف التحدّي اليومي لهذا السيرفر.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const channel = interaction.options.getChannel("channel", true);
  const time = interaction.options.getString("time", true);
  const timeZone = interaction.options.getString("timezone", true);
  if (
    channel.type !== ChannelType.GuildText &&
    channel.type !== ChannelType.GuildAnnouncement
  ) {
    throw new RangeError("اختار قناة نصية أو قناة إعلانات.");
  }
  if (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time)) {
    throw new RangeError("اكتب الوقت بصيغة 24 ساعة، مثل 18:30.");
  }
  try {
    new Intl.DateTimeFormat("en-US", { timeZone }).format(new Date());
  } catch {
    throw new RangeError(
      "المنطقة الزمنية غير معروفة. جرّب مثلاً Asia/Baghdad أو UTC.",
    );
  }

  await featureStore.configureDaily(interaction.guildId, {
    channelId: channel.id,
    time,
    timeZone,
  });
  await interaction.reply({
    content: `تم ضبط التحدّي اليومي في <#${channel.id}> يومياً الساعة **${time}** (${timeZone}).`,
    flags: MessageFlags.Ephemeral,
  });
}

async function sendHelp(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await interaction.reply({
    embeds: [helpEmbed()],
    flags: MessageFlags.Ephemeral,
  });
}

function getMessageGuild(message: Message): {
  guildId: string;
  guild: NonNullable<Message["guild"]>;
} {
  if (!message.guildId || !message.guild) {
    throw new RangeError("أوامر البوت متاحة داخل السيرفرات فقط.");
  }
  return { guildId: message.guildId, guild: message.guild };
}

function getChoiceOption<T extends Record<string, unknown>>(
  options: Record<string, string>,
  name: string,
  choices: T,
): keyof T | undefined {
  const value = options[name];
  if (!value) return undefined;
  if (!Object.hasOwn(choices, value)) {
    throw new RangeError(
      `قيمة الخيار \`${name}\` غير صحيحة. استخدم \`*help\` لعرض الخيارات.`,
    );
  }
  return value as keyof T;
}

async function createPrefixChallenge(
  store: ChallengeCycleStore,
  ownerId: string,
  guildId: string,
  categoryId: ChallengeCategoryId | undefined,
  options: PrefixChallengeOptions,
): Promise<{ idea: SelectedIdea; session: ChallengeSession }> {
  const idea = await store.next(guildId, categoryId);
  const colors = options.includeColors
    ? choosePalette(randomInt(2, 5))
    : undefined;
  return {
    idea,
    session: {
      ownerId,
      guildId,
      currentIdeaId: idea.id,
      ...(categoryId ? { categoryId } : {}),
      ...(options.difficulty ? { difficulty: options.difficulty } : {}),
      ...(options.duration ? { duration: options.duration } : {}),
      ...(colors ? { colors } : {}),
      ...(options.style ? { style: options.style } : {}),
      ...(options.twist ? { twist: options.twist } : {}),
      ...(options.focus ? { focus: options.focus } : {}),
      ...(options.format ? { format: options.format } : {}),
    },
  };
}

async function sendPrefixChallenge(
  message: Message,
  argumentText: string,
  store: ChallengeCycleStore,
): Promise<void> {
  const { guildId } = getMessageGuild(message);
  const { options, positionalText } = parseNamedArguments(argumentText);
  const allowedOptions = new Set([
    "theme",
    "difficulty",
    "duration",
    "colors",
    "style",
    "twist",
    "focus",
    "format",
  ]);
  const unknownOptions = Object.keys(options).filter(
    (name) => !allowedOptions.has(name),
  );
  if (unknownOptions.length > 0) {
    throw new RangeError(`خيار غير معروف: ${unknownOptions[0]}.`);
  }

  const positionalTokens = positionalText
    .split(/\s+/)
    .filter(Boolean)
    .map((token) => token.toLowerCase());
  const positionalTheme = positionalTokens.find((token) => token !== "colors");
  if (positionalTokens.some((token) => token !== "colors" && token !== positionalTheme)) {
    throw new RangeError(
      "استخدم *challenge theme=animals أو اكتب *challenge لاختيار الفئة من القائمة.",
    );
  }
  const themeValue = options["theme"] ?? positionalTheme;
  const categoryId = getSelectedCategory(themeValue ?? null);
  if (themeValue && !categoryId) {
    throw new RangeError(
      "ما عرفت الفئة. اكتب *challenge حتى تختارها من القائمة.",
    );
  }

  const difficulty = getChoiceOption(
    options,
    "difficulty",
    difficultyDetails,
  ) as Difficulty | undefined;
  const durationValue = options["duration"];
  const duration = durationValue ? Number(durationValue) : undefined;
  if (
    durationValue &&
    (!Number.isInteger(duration) || ![15, 30, 60].includes(duration!))
  ) {
    throw new RangeError("المدة المتاحة هي 15 أو 30 أو 60 دقيقة.");
  }

  const colorValue = options["colors"]?.toLowerCase();
  if (colorValue && !["true", "false", "yes", "no"].includes(colorValue)) {
    throw new RangeError("اكتب colors=true أو أضف كلمة colors للأمر.");
  }
  const includeColors =
    colorValue === "true" ||
    colorValue === "yes" ||
    positionalTokens.includes("colors");
  const style = getChoiceOption(options, "style", challengeStyles) as
    | ChallengeStyle
    | undefined;
  const twist = getChoiceOption(options, "twist", challengeTwists) as
    | ChallengeTwist
    | undefined;
  const focus = getChoiceOption(options, "focus", challengeFocusDetails) as
    | ChallengeFocus
    | undefined;
  const format = getChoiceOption(options, "format", challengeFormatDetails) as
    | ChallengeFormat
    | undefined;

  const challengeOptions: PrefixChallengeOptions = {
    includeColors,
    ...(difficulty ? { difficulty } : {}),
    ...(duration ? { duration } : {}),
    ...(style ? { style } : {}),
    ...(twist ? { twist } : {}),
    ...(focus ? { focus } : {}),
    ...(format ? { format } : {}),
  };

  if (!categoryId) {
    const selectionMessage = await message.reply({
      content:
        "اختار فئة التحدّي من القائمة، أو اختار «اختيار عشوائي» حتى يختار البوت فئة لك.",
      components: [challengeCategoryRow()],
    });
    if (pendingChallengeCategorySessions.size >= maxChallengeSessions) {
      const oldestMessageId =
        pendingChallengeCategorySessions.keys().next().value;
      if (oldestMessageId) {
        pendingChallengeCategorySessions.delete(oldestMessageId);
      }
    }
    pendingChallengeCategorySessions.set(selectionMessage.id, {
      ownerId: message.author.id,
      guildId,
      options: challengeOptions,
    });
    return;
  }

  const { idea, session } = await createPrefixChallenge(
    store,
    message.author.id,
    guildId,
    categoryId,
    challengeOptions,
  );
  const sentMessage = await message.reply({
    embeds: [challengeEmbed(idea, session)],
    components: [challengeButtons()],
  });
  saveChallengeSession(sentMessage.id, session);
}

async function sendPrefixCharacterForm(
  message: Message,
  argumentText: string,
): Promise<void> {
  const { options, positionalText } = parseNamedArguments(argumentText);
  if (positionalText) {
    throw new RangeError(
      'حدد الخيارات بصيغة trait="value"، أو اتركها فارغة ليختارها البوت.',
    );
  }

  const selections: CharacterSelections = {};
  for (const [traitId, value] of Object.entries(options)) {
    const trait = characterTraitDefinitions.find(({ id }) => id === traitId);
    if (!trait) throw new RangeError(`خيار شخصية غير معروف: ${traitId}.`);
    if (!(trait.choices as readonly string[]).includes(value)) {
      throw new RangeError(`القيمة غير متاحة للخيار ${traitId}.`);
    }
    Object.assign(selections, { [traitId]: value });
  }

  const profile = createCharacterProfile(selections);
  let sentMessage: Message | undefined;
  let lastError: unknown;

  // Discord image uploads can fail transiently. Retry once, then keep the
  // character command usable with the character card even if attachments fail.
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const characterImages = characterImagePayload(profile);
      sentMessage = await message.reply({
        ...characterImages,
        components: [characterButtons()],
      });
      break;
    } catch (error) {
      lastError = error;
      logger.warn(
        { err: error, attempt: attempt + 1 },
        "Character form image upload failed; retrying",
      );
      if (attempt === 0) {
        await new Promise((resolve) => setTimeout(resolve, 800));
      }
    }
  }

  if (!sentMessage) {
    sentMessage = await message.reply({
      embeds: [characterEmbed(profile)],
      content:
        "تم إنشاء الشخصية، لكن تعذّر إرفاق صور المراجع مؤقتاً. اضغط «شخصية ثانية» للمحاولة مرة أخرى.",
      components: [characterButtons()],
    });
    logger.warn(
      { err: lastError },
      "Character form used text-only fallback after image upload failures",
    );
  }

  saveCharacterSession(sentMessage.id, {
    ownerId: message.author.id,
    selections,
  });
}

async function sendPrefixPoseGallery(message: Message): Promise<void> {
  const page = 0;
  const visiblePoses = poseReferences.slice(0, posesPerGalleryPage);
  const sentMessage = await message.reply({
    content: `معرض البوزات — الصفحة 1 من ${poseGalleryPageCount()}. اختار بوزاً من القائمة لعرض الشرح الكامل.`,
    embeds: poseGalleryPageEmbeds(page),
    files: visiblePoses.map((pose) => poseAttachment(pose.label)),
    components: poseGalleryComponents(page),
  });
  savePoseGallerySession(sentMessage.id, { ownerId: message.author.id, page });
}

async function sendPrefixSuggestion(
  message: Message,
  argumentText: string,
  featureStore: BotFeatureStore,
): Promise<void> {
  const { guildId } = getMessageGuild(message);
  const { options, positionalText } = parseNamedArguments(argumentText);
  const unknownOptions = Object.keys(options).filter(
    (name) => name !== "theme" && name !== "prompt",
  );
  if (unknownOptions.length > 0) {
    throw new RangeError(`خيار غير معروف: ${unknownOptions[0]}.`);
  }
  const prompt = (options["prompt"] ?? positionalText).trim();
  if (!prompt) {
    throw new RangeError(
      'اكتب الفكرة بعد الأمر، مثال: *suggest فكرة رسم جديدة',
    );
  }
  const theme = options["theme"];
  const category = theme
    ? getSelectedCategory(theme)
    : "community";
  if (!category) throw new RangeError("الفئة غير معروفة. استخدم *help.");

  const suggestion = await featureStore.submitIdea(
    guildId,
    prompt,
    category,
    message.author.id,
  );
  await message.reply(
    "وصل اقتراحك للمراجعة. إذا اعتمده مشرف السيرفر، راح يظهر ضمن أفكار المجتمع.",
  );
  logger.info(
    { guildId, suggestionId: suggestion.id },
    "A community drawing idea was submitted",
  );
}

async function sendPrefixIdeaReview(
  message: Message,
  featureStore: BotFeatureStore,
): Promise<void> {
  const { guildId } = getMessageGuild(message);
  if (!message.member?.permissions.has(PermissionFlagsBits.ManageGuild)) {
    throw new RangeError("هذا الأمر متاح لمشرفي السيرفر فقط.");
  }
  const suggestion = featureStore.listPendingIdeas(guildId, 1)[0];
  if (!suggestion) {
    await message.reply("ماكو اقتراحات جديدة بانتظار المراجعة.");
    return;
  }
  await message.reply({
    embeds: [ideaSuggestionEmbed(suggestion)],
    components: [ideaReviewButtons(suggestion.id)],
  });
}

async function sendPrefixCommunityIdea(
  message: Message,
  featureStore: BotFeatureStore,
): Promise<void> {
  const { guildId } = getMessageGuild(message);
  const idea = chooseCommunityIdea(featureStore, guildId);
  if (!idea) {
    await message.reply(
      "ماكو أفكار مجتمعية معتمدة بعد. استخدم *suggest حتى تقترح فكرة، وبعد مراجعتها تظهر هنا.",
    );
    return;
  }
  const sentMessage = await message.reply({
    embeds: [communityIdeaEmbed(idea, featureStore)],
    components: [communityButtons(featureStore.getVoteCounts(idea.id).removed)],
  });
  saveCommunitySession(sentMessage.id, { guildId, ideaId: idea.id });
}

async function sendPrefixDailyConfiguration(
  message: Message,
  argumentText: string,
  featureStore: BotFeatureStore,
): Promise<void> {
  const { guildId, guild } = getMessageGuild(message);
  if (!message.member?.permissions.has(PermissionFlagsBits.ManageGuild)) {
    throw new RangeError("إعداد التحدّي اليومي متاح لمشرفي السيرفر فقط.");
  }

  if (argumentText.trim().toLowerCase() === "off") {
    await featureStore.disableDaily(guildId);
    await message.reply("تم إيقاف التحدّي اليومي لهذا السيرفر.");
    return;
  }

  const match = argumentText.match(
    /^set\s+<#(\d+)>\s+((?:[01]\d|2[0-3]):[0-5]\d)\s+(\S+)$/i,
  );
  if (!match) {
    throw new RangeError(
      "الاستخدام: *daily set #القناة 18:30 Asia/Baghdad أو *daily off.",
    );
  }
  const channelId = match[1]!;
  const time = match[2]!;
  const timeZone = match[3]!;
  const channel = await guild.channels.fetch(channelId);
  if (
    !channel ||
    (channel.type !== ChannelType.GuildText &&
      channel.type !== ChannelType.GuildAnnouncement)
  ) {
    throw new RangeError("اختار قناة نصية أو قناة إعلانات.");
  }
  try {
    new Intl.DateTimeFormat("en-US", { timeZone }).format(new Date());
  } catch {
    throw new RangeError(
      "المنطقة الزمنية غير معروفة. جرّب مثلاً Asia/Baghdad أو UTC.",
    );
  }

  await featureStore.configureDaily(guildId, {
    channelId,
    time,
    timeZone,
  });
  await message.reply(
    `تم ضبط التحدّي اليومي في <#${channelId}> يومياً الساعة **${time}** (${timeZone}).`,
  );
}

async function handlePrefixCommand(
  message: Message,
  command: string,
  argumentText: string,
  store: ChallengeCycleStore,
  featureStore: BotFeatureStore,
): Promise<void> {
  switch (command) {
    case "challenge":
      await sendPrefixChallenge(message, argumentText, store);
      return;
    case "form":
      await sendPrefixCharacterForm(message, argumentText);
      return;
    case "poses":
      await sendPrefixPoseGallery(message);
      return;
    case "suggest":
      await sendPrefixSuggestion(message, argumentText, featureStore);
      return;
    case "review":
      await sendPrefixIdeaReview(message, featureStore);
      return;
    case "community":
      await sendPrefixCommunityIdea(message, featureStore);
      return;
    case "daily":
      await sendPrefixDailyConfiguration(message, argumentText, featureStore);
      return;
    case "help":
      await message.reply({ embeds: [helpEmbed()] });
      return;
    default:
      await message.reply("ما عرفت هذا الأمر. استخدم `*help` لعرض الأوامر.");
  }
}

async function handlePrefixCommandError(
  message: Message,
  error: unknown,
): Promise<void> {
  logger.error(
    { err: error, guildId: message.guildId },
    "Failed to handle a prefix drawing challenge command",
  );
  const content =
    error instanceof NoIdeasInCategoryError
      ? "انتهت الأفكار المتاحة من هذه الفئة في الدورة الحالية. اختر فئة أخرى أو اترك theme فارغاً."
      : error instanceof RangeError
        ? error.message
        : "تعذّر تنفيذ الأمر هذه المرة. حاول مرة ثانية بعد قليل.";
  try {
    await message.reply({
      content,
      allowedMentions: { repliedUser: false },
    });
  } catch (replyError) {
    logger.error({ err: replyError }, "Failed to reply to a prefix command");
  }
}

async function handleCommandError(
  interaction: ChatInputCommandInteraction,
  error: unknown,
): Promise<void> {
  logger.error({ err: error }, "Failed to handle a drawing challenge command");
  if (!interaction.isRepliable() || interaction.replied) return;

  const content =
    error instanceof NoIdeasInCategoryError
      ? "انتهت الأفكار المتاحة من هذه الفئة في الدورة الحالية. اختر فئة أخرى أو اترك `theme` فارغاً؛ تتجدد الدورة العامة بعد استهلاك أفكارها."
      : error instanceof RangeError
        ? error.message
      : "تعذّر تنفيذ الأمر هذه المرة. حاول مرة ثانية بعد قليل.";

  try {
    if (interaction.deferred) {
      await interaction.editReply({ content, embeds: [], components: [] });
      return;
    }
    await interaction.reply({
      content,
      flags: MessageFlags.Ephemeral,
    });
  } catch (replyError) {
    logger.error(
      { err: replyError },
      "Failed to send the drawing challenge error response",
    );
  }
}

async function handleChallengeButton(
  interaction: ButtonInteraction,
  store: ChallengeCycleStore,
): Promise<void> {
  const session = challengeSessions.get(interaction.message.id);

  if (!session) {
    await interaction.reply({
      content:
        "انتهت صلاحية هذه الأزرار. استخدم `*challenge` لبدء تحدٍّ جديد.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (session.ownerId && interaction.user.id !== session.ownerId) {
    await interaction.reply({
      content: "هذه الأزرار متاحة لمن بدأ هذا التحدّي فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await interaction.deferUpdate();

  if (interaction.customId === challengeButtonIds.next) {
    const idea = await store.next(
      session.guildId,
      session.categoryId,
      session.currentIdeaId,
    );
    const nextSession = { ...session, currentIdeaId: idea.id };

    await interaction.message.edit({
      embeds: [
        challengeEmbed(idea, {
          difficulty: nextSession.difficulty,
          duration: nextSession.duration,
          colors: nextSession.colors,
          style: nextSession.style,
          twist: nextSession.twist,
          focus: nextSession.focus,
          format: nextSession.format,
        }),
      ],
      components: [challengeButtons()],
    });
    challengeSessions.set(interaction.message.id, nextSession);
    return;
  }

  if (interaction.customId === challengeButtonIds.remix) {
    const idea = drawingIdeas.find(({ id }) => id === session.currentIdeaId);
    if (!idea) throw new Error("The active challenge idea is no longer available.");

    const nextSession = {
      ...session,
      style: randomRecordKey(challengeStyles),
      twist: randomRecordKey(challengeTwists),
      focus: randomRecordKey(challengeFocusDetails),
      format: randomRecordKey(challengeFormatDetails),
    };
    await interaction.message.edit({
      embeds: [
        challengeEmbed(
          { id: idea.id, prompt: idea.prompt, category: idea.category },
          {
            difficulty: nextSession.difficulty,
            duration: nextSession.duration,
            colors: nextSession.colors,
            style: nextSession.style,
            twist: nextSession.twist,
            focus: nextSession.focus,
            format: nextSession.format,
          },
        ),
      ],
      components: [challengeButtons()],
    });
    challengeSessions.set(interaction.message.id, nextSession);
    return;
  }

  const nextSession = { ...session, colors: choosePalette(randomInt(2, 5)) };
  const idea = drawingIdeas.find(({ id }) => id === session.currentIdeaId);
  if (!idea) throw new Error("The active challenge idea is no longer available.");

  await interaction.message.edit({
    embeds: [
      challengeEmbed(
        {
          id: idea.id,
          prompt: idea.prompt,
          category: idea.category,
        },
        {
          difficulty: nextSession.difficulty,
          duration: nextSession.duration,
          colors: nextSession.colors,
          style: nextSession.style,
          twist: nextSession.twist,
          focus: nextSession.focus,
          format: nextSession.format,
        },
      ),
    ],
    components: [challengeButtons()],
  });
  challengeSessions.set(interaction.message.id, nextSession);
}

async function handleChallengeCategorySelection(
  interaction: StringSelectMenuInteraction,
  store: ChallengeCycleStore,
): Promise<void> {
  const session = pendingChallengeCategorySessions.get(interaction.message.id);
  if (!session) {
    await interaction.reply({
      content: "انتهت صلاحية هذه القائمة. اكتب `*challenge` حتى تختار من جديد.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (interaction.user.id !== session.ownerId) {
    await interaction.reply({
      content: "هذه القائمة متاحة لمن بدأ التحدّي فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (session.processing) {
    await interaction.reply({
      content: "جاري تجهيز التحدّي، انتظر لحظة.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const selectedValue = interaction.values[0];
  const categoryId =
    selectedValue === "random" ? undefined : getSelectedCategory(selectedValue ?? null);
  if (selectedValue !== "random" && !categoryId) {
    await interaction.reply({
      content: "ما عرفت هذه الفئة. اكتب `*challenge` حتى تختار من جديد.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (interaction.guildId !== session.guildId) {
    await interaction.reply({
      content: "هذه القائمة تخص سيرفر آخر. اكتب `*challenge` هنا.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  session.processing = true;
  try {
    await interaction.deferUpdate();
    const { idea, session: challengeSession } = await createPrefixChallenge(
      store,
      session.ownerId,
      session.guildId,
      categoryId,
      session.options,
    );
    await interaction.message.edit({
      content: null,
      embeds: [challengeEmbed(idea, challengeSession)],
      components: [challengeButtons()],
    });
    pendingChallengeCategorySessions.delete(interaction.message.id);
    saveChallengeSession(interaction.message.id, challengeSession);
  } catch (error) {
    session.processing = false;
    throw error;
  }
}

async function handleCharacterButton(
  interaction: ButtonInteraction,
): Promise<void> {
  const session = characterSessions.get(interaction.message.id);

  if (!session) {
    await interaction.reply({
      content: "انتهت صلاحية هذا الزر. استخدم `*form` لتكوين شخصية جديدة.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (interaction.user.id !== session.ownerId) {
    await interaction.reply({
      content: "هذا الزر متاح لمن أنشأ الشخصية فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await interaction.deferUpdate();
  const profile = createCharacterProfile(session.selections);
  let lastError: unknown;

  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const characterImages = characterImagePayload(profile);
      await interaction.message.edit({
        ...characterImages,
        attachments: [],
        components: [characterButtons()],
      });
      return;
    } catch (error) {
      lastError = error;
      logger.warn(
        { err: error, attempt: attempt + 1 },
        "Character reroll image upload failed; retrying",
      );
      if (attempt === 0) {
        await new Promise((resolve) => setTimeout(resolve, 800));
      }
    }
  }

  // The interaction is already acknowledged, so update the message with the
  // character card instead of leaving the user with a generic error.
  await interaction.message.edit({
    embeds: [characterEmbed(profile)],
    content:
      "تم تغيير الشخصية، لكن تعذّر إرفاق صور المراجع مؤقتاً. اضغط «شخصية ثانية» للمحاولة مرة أخرى.",
    attachments: [],
    components: [characterButtons()],
  });
  logger.warn(
    { err: lastError },
    "Character reroll used text-only fallback after image upload failures",
  );
}

async function handlePoseSelection(
  interaction: StringSelectMenuInteraction,
): Promise<void> {
  const pose = getPoseReferenceById(interaction.values[0] ?? "");
  if (!pose) {
    await interaction.reply({
      content: "ما لكيت هذا البوز. افتح `*poses` حتى تختار من جديد.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const gallerySession = poseGallerySessions.get(interaction.message.id);
  const page = gallerySession?.page ?? 0;
  await interaction.update({
    embeds: [poseEmbed(pose)],
    files: [poseAttachment(pose.label)],
    attachments: [],
    components: poseGalleryComponents(page),
  });
}

async function handleIdeaReviewButton(
  interaction: ButtonInteraction,
  featureStore: BotFeatureStore,
): Promise<void> {
  if (!interaction.guildId) {
    await interaction.reply({
      content: "مراجعة الاقتراحات متاحة داخل السيرفرات فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    await interaction.reply({
      content: "اعتماد الاقتراحات متاح لمشرفي السيرفر فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const match = interaction.customId.match(
    /^aidea:review:(approve|reject):([a-f0-9-]+)$/i,
  );
  if (!match) return;

  const approve = match[1] === "approve";
  const result = await featureStore.reviewIdea(
    interaction.guildId,
    match[2]!,
    approve,
    interaction.user.id,
  );
  const category = challengeCategories.find(
    ({ id }) => id === result.suggestion.category,
  );
  const embed = new EmbedBuilder()
    .setTitle(approve ? "تم اعتماد الفكرة" : "تم رفض الفكرة")
    .setDescription(result.suggestion.prompt)
    .setColor(approve ? 0x3b9b83 : 0xc34f4f)
    .addFields({
      name: "الفئة",
      value: category?.name ?? "متنوعة",
      inline: true,
    })
    .setFooter({ text: `تمت المراجعة بواسطة ${interaction.user.username}` });
  await interaction.update({ embeds: [embed], components: [] });
}

async function handleCommunityButton(
  interaction: ButtonInteraction,
  featureStore: BotFeatureStore,
): Promise<void> {
  const session = communitySessions.get(interaction.message.id);
  if (!session) {
    await interaction.reply({
      content: "انتهت صلاحية هذا الزر. استخدم `*community` لعرض فكرة جديدة.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (interaction.customId === communityButtonIds.next) {
    const idea = chooseCommunityIdea(
      featureStore,
      session.guildId,
      session.ideaId,
    );
    if (!idea) {
      communitySessions.delete(interaction.message.id);
      await interaction.update({
        content: "ماكو أفكار مجتمعية متاحة حالياً.",
        embeds: [],
        components: [],
      });
      return;
    }

    await interaction.update({
      embeds: [communityIdeaEmbed(idea, featureStore)],
      components: [communityButtons(featureStore.getVoteCounts(idea.id).removed)],
    });
    saveCommunitySession(interaction.message.id, {
      guildId: session.guildId,
      ideaId: idea.id,
    });
    return;
  }

  const vote: IdeaVote =
    interaction.customId === communityButtonIds.up ? "up" : "down";
  const counts = await featureStore.castVote(
    session.ideaId,
    interaction.user.id,
    vote,
  );
  const idea = featureStore
    .getApprovedIdeas(session.guildId)
    .find(({ id }) => id === session.ideaId);
  if (!idea) throw new Error("The active community idea no longer exists.");

  await interaction.update({
    embeds: [communityIdeaEmbed(idea, featureStore)],
    components: [communityButtons(counts.removed)],
  });
}

async function handleButtonError(
  interaction: ButtonInteraction,
  error: unknown,
): Promise<void> {
  logger.error({ err: error }, "Failed to handle a drawing challenge button");
  if (!interaction.isRepliable()) return;

  const content =
    error instanceof NoIdeasInCategoryError
      ? "انتهت الأفكار المتاحة من هذه الفئة في الدورة الحالية. اختر فئة أخرى أو ابدأ تحدّياً جديداً."
      : "تعذّر تحديث التحدّي. حاول مرة ثانية بعد قليل.";

  try {
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp({
        content,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    await interaction.reply({
      content,
      flags: MessageFlags.Ephemeral,
    });
  } catch (replyError) {
    logger.error(
      { err: replyError },
      "Failed to send the drawing challenge button error response",
    );
  }
}

async function handleCharacterButtonError(
  interaction: ButtonInteraction,
  error: unknown,
): Promise<void> {
  logger.error({ err: error }, "Failed to generate another character");
  if (!interaction.isRepliable()) return;

  try {
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp({
        content: "تعذّر تكوين شخصية ثانية. حاول مرة أخرى.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    await interaction.reply({
      content: "تعذّر تكوين شخصية ثانية. حاول مرة أخرى.",
      flags: MessageFlags.Ephemeral,
    });
  } catch (replyError) {
    logger.error(
      { err: replyError },
      "Failed to send the character generation error response",
    );
  }
}

async function handlePoseSelectionError(
  interaction: StringSelectMenuInteraction,
  error: unknown,
): Promise<void> {
  logger.error({ err: error }, "Failed to apply a pose reference");
  try {
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp({
        content: "تعذّر عرض هذا البوز. حاول اختيار بوز ثاني.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    await interaction.reply({
      content: "تعذّر عرض هذا البوز. حاول اختيار بوز ثاني.",
      flags: MessageFlags.Ephemeral,
    });
  } catch (replyError) {
    logger.error({ err: replyError }, "Failed to report a pose selection error");
  }
}

async function handleChallengeCategorySelectionError(
  interaction: StringSelectMenuInteraction,
  error: unknown,
): Promise<void> {
  logger.error(
    { err: error, guildId: interaction.guildId },
    "Failed to create a challenge from the category menu",
  );
  const content =
    error instanceof NoIdeasInCategoryError
      ? "ماكو أفكار متاحة حالياً في هذه الفئة. اختار فئة ثانية أو جرّب «اختيار عشوائي»."
      : "تعذّر إنشاء التحدّي. اختار فئة ثانية أو اكتب `*challenge` حتى تحاول مرة ثانية.";
  try {
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp({
        content,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    await interaction.reply({
      content,
      flags: MessageFlags.Ephemeral,
    });
  } catch (replyError) {
    logger.error(
      { err: replyError },
      "Failed to report a challenge category menu error",
    );
  }
}

async function publishDueDailyChallenges(
  client: Client,
  cycleStore: ChallengeCycleStore,
  featureStore: BotFeatureStore,
): Promise<void> {
  for (const { guildId, config } of featureStore.getDailySchedules()) {
    try {
      const local = getLocalDateAndTime(config.timeZone);
      if (local.time < config.time) continue;
      if (!(await featureStore.claimDailyPost(guildId, local.date))) continue;

      const channel = await client.channels.fetch(config.channelId);
      if (!channel?.isTextBased() || !("send" in channel)) {
        logger.warn(
          { guildId, channelId: config.channelId },
          "Daily challenge channel is unavailable or not text-based",
        );
        continue;
      }

      const idea = await cycleStore.next(guildId);
      const message = await channel.send({
        embeds: [challengeEmbed(idea, {})],
        components: [challengeButtons()],
      });
      await featureStore.recordDailyPost(guildId, local.date, message.id);
      saveChallengeSession(message.id, {
        ownerId: "",
        guildId,
        currentIdeaId: idea.id,
      });
      logger.info(
        { guildId, channelId: config.channelId, date: local.date },
        "Daily drawing challenge posted",
      );
    } catch (error) {
      logger.error({ err: error, guildId }, "Failed to post a daily challenge");
    }
  }
}

function startDailyChallengeScheduler(
  client: Client,
  cycleStore: ChallengeCycleStore,
  featureStore: BotFeatureStore,
): void {
  const run = () => {
    void publishDueDailyChallenges(client, cycleStore, featureStore);
  };
  run();
  setInterval(run, 60_000);
}

export async function startDiscordBot(token: string): Promise<Client> {
  if (drawingIdeas.length < 400) {
    throw new Error("The drawing idea bank is incomplete.");
  }

  const store = new ChallengeCycleStore();
  await store.initialize();
  const featureStore = new BotFeatureStore();
  await featureStore.initialize();

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
    ],
  });

  client.once(Events.ClientReady, (readyClient) => {
    logger.info("Discord drawing challenge bot is ready");
    startDailyChallengeScheduler(readyClient, store, featureStore);

    void (async () => {
      for (const guild of readyClient.guilds.cache.values()) {
        try {
          if (process.env["CLEAR_LEGACY_SLASH_COMMANDS"] === "true") {
            await removeGuildSlashCommands(guild);
          } else {
            await syncGuildSlashCommands(guild);
          }
        } catch (error) {
          logger.error({ err: error, guildId: guild.id }, "Failed to synchronize Discord slash commands");
        }
      }
    })();
  });

  client.on(Events.GuildCreate, (guild) => {
    const action = process.env["CLEAR_LEGACY_SLASH_COMMANDS"] === "true"
      ? removeGuildSlashCommands(guild)
      : syncGuildSlashCommands(guild);
    void action.catch((error: unknown) => {
      logger.error({ err: error, guildId: guild.id }, "Failed to synchronize slash commands for new guild");
    });
  });

  client.on(Events.MessageCreate, (message) => {
    if (message.author.bot) return;
    const parsed = parsePrefixCommand(message.content);
    if (!parsed) return;
    void handlePrefixCommand(
      message,
      parsed.command,
      parsed.argumentText,
      store,
      featureStore,
    ).catch((error: unknown) => handlePrefixCommandError(message, error));
  });

  client.on(Events.InteractionCreate, (interaction) => {
    if (interaction.isButton()) {
      if (
        interaction.customId === posePageButtonIds.previous ||
        interaction.customId === posePageButtonIds.next
      ) {
        void handlePosePageButton(interaction).catch((error: unknown) =>
          handleButtonError(interaction, error),
        );
        return;
      }
      if (interaction.customId === characterButtonIds.reroll) {
        void handleCharacterButton(interaction).catch((error: unknown) =>
          handleCharacterButtonError(interaction, error),
        );
        return;
      }
      if (interaction.customId.startsWith(ideaReviewButtonPrefix)) {
        void handleIdeaReviewButton(interaction, featureStore).catch(
          (error: unknown) => handleButtonError(interaction, error),
        );
        return;
      }
      if (Object.values(communityButtonIds).includes(interaction.customId as (typeof communityButtonIds)[keyof typeof communityButtonIds])) {
        void handleCommunityButton(interaction, featureStore).catch(
          (error: unknown) => handleButtonError(interaction, error),
        );
        return;
      }
      if (
        interaction.customId !== challengeButtonIds.next &&
        interaction.customId !== challengeButtonIds.colors &&
        interaction.customId !== challengeButtonIds.remix
      ) {
        return;
      }
      void handleChallengeButton(interaction, store).catch((error: unknown) =>
        handleButtonError(interaction, error),
      );
      return;
    }

    if (interaction.isStringSelectMenu()) {
      if (interaction.customId === challengeCategoryMenuId) {
        void handleChallengeCategorySelection(interaction, store).catch(
          (error: unknown) =>
            handleChallengeCategorySelectionError(interaction, error),
        );
        return;
      }
      if (interaction.customId !== poseMenuIds.gallery) {
        return;
      }
      void handlePoseSelection(interaction).catch((error: unknown) =>
        handlePoseSelectionError(interaction, error),
      );
      return;
    }

    if (!interaction.isChatInputCommand()) return;

    const handler =
      interaction.commandName === challengeCommand.name
        ? () => sendChallenge(interaction, store)
        : interaction.commandName === formCommand.name
          ? () => sendCharacterForm(interaction)
          : interaction.commandName === helpCommand.name
            ? () => sendHelp(interaction)
            : interaction.commandName === poseGalleryCommand.name
              ? () => sendPoseGallery(interaction)
              : interaction.commandName === suggestCommand.name
                ? () => sendIdeaSuggestion(interaction, featureStore)
                : interaction.commandName === reviewCommand.name
                  ? () => sendIdeaReview(interaction, featureStore)
                  : interaction.commandName === communityCommand.name
                    ? () => sendCommunityIdea(interaction, featureStore)
                    : interaction.commandName === dailyCommand.name
                      ? () => sendDailyConfiguration(interaction, featureStore)
            : undefined;

    if (handler) {
      void handler().catch((error: unknown) =>
        handleCommandError(interaction, error),
      );
    }
  });

  client.on(Events.Error, (error) => {
    logger.error({ err: error }, "Discord client error");
  });

  await client.login(token);
  return client;
}