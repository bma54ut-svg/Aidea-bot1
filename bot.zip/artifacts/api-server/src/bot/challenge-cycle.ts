import { randomInt } from "node:crypto";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import {
  drawingIdeas,
  type ChallengeCategoryId,
} from "./ideas";

interface StoredGuildCycle {
  remaining: string[];
  ideaBankVersion?: number;
}

interface GuildCycle extends StoredGuildCycle {
  ideaBankVersion: number;
}

type StoredCycles = Record<string, GuildCycle>;

export const currentIdeaBankVersion = 5;

const legacyIdeaCount = 470;
const newIdeaIdsByVersion = new Map<number, string[]>([
  [
    2,
    drawingIdeas.slice(legacyIdeaCount, 700).map(({ id }) => id),
  ],
  [
    3,
    drawingIdeas.slice(700, 750).map(({ id }) => id),
  ],
  [
    4,
    drawingIdeas.slice(750, 830).map(({ id }) => id),
  ],
  [
    5,
    drawingIdeas.slice(830).map(({ id }) => id),
  ],
]);

export interface SelectedIdea {
  id: string;
  prompt: string;
  category: ChallengeCategoryId;
}

const ideaIds = new Set(drawingIdeas.map(({ id }) => id));
const ideasById = new Map(drawingIdeas.map((idea) => [idea.id, idea]));
const stateFile = process.env["DATA_DIR"]
  ? resolve(process.env["DATA_DIR"], "challenge-cycles.json")
  : resolve(dirname(fileURLToPath(import.meta.url)), "../data/challenge-cycles.json");

function shuffledIdeaIds(categoryId?: ChallengeCategoryId): string[] {
  const ids = drawingIdeas
    .filter((idea) => !categoryId || idea.category === categoryId)
    .map(({ id }) => id);
  for (let index = ids.length - 1; index > 0; index -= 1) {
    const swapIndex = randomInt(index + 1);
    [ids[index], ids[swapIndex]] = [ids[swapIndex], ids[index]];
  }
  return ids;
}

function isValidCycle(value: unknown): value is StoredGuildCycle {
  if (typeof value !== "object" || value === null) return false;
  const cycle = value as Partial<StoredGuildCycle>;
  return (
    Array.isArray(cycle.remaining) &&
    cycle.remaining.every(
      (id) => typeof id === "string" && ideaIds.has(id),
    ) &&
    new Set(cycle.remaining).size === cycle.remaining.length &&
    (cycle.ideaBankVersion === undefined ||
      (Number.isInteger(cycle.ideaBankVersion) &&
        cycle.ideaBankVersion >= 1 &&
        cycle.ideaBankVersion <= currentIdeaBankVersion))
  );
}

function migrateCycle(cycle: StoredGuildCycle): GuildCycle {
  const previousVersion = cycle.ideaBankVersion ?? 1;
  const remaining = [...cycle.remaining];

  for (
    let version = previousVersion + 1;
    version <= currentIdeaBankVersion;
    version += 1
  ) {
    const newIdeaIds = newIdeaIdsByVersion.get(version);
    if (!newIdeaIds) {
      throw new Error(`No drawing idea migration exists for version ${version}.`);
    }

    const knownRemaining = new Set(remaining);
    remaining.push(...newIdeaIds.filter((id) => !knownRemaining.has(id)));
  }

  return {
    remaining,
    ideaBankVersion: currentIdeaBankVersion,
  };
}

export class NoIdeasInCategoryError extends Error {
  constructor(readonly categoryId: ChallengeCategoryId) {
    super("No new drawing ideas remain in this category for the current cycle.");
    this.name = "NoIdeasInCategoryError";
  }
}

export class ChallengeCycleStore {
  private cycles: StoredCycles = {};
  private initialized = false;
  private queue: Promise<void> = Promise.resolve();
  private readonly statePath: string;

  constructor(statePath = stateFile) {
    this.statePath = statePath;
  }

  async initialize(): Promise<void> {
    await mkdir(dirname(this.statePath), { recursive: true });

    try {
      const rawState = await readFile(this.statePath, "utf8");
      const parsed: unknown = JSON.parse(rawState);
      if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
        throw new Error("Challenge cycle state must be an object.");
      }

      const loaded = parsed as Record<string, unknown>;
      for (const [guildId, value] of Object.entries(loaded)) {
        if (!isValidCycle(value)) {
          throw new Error(`Challenge cycle state is invalid for guild ${guildId}.`);
        }
        this.cycles[guildId] = migrateCycle(value);
      }
    } catch (error) {
      if (
        typeof error === "object" &&
        error !== null &&
        "code" in error &&
        error.code === "ENOENT"
      ) {
        this.cycles = {};
      } else {
        throw error;
      }
    }

    this.initialized = true;
  }

  async next(
    guildId: string,
    categoryId?: ChallengeCategoryId,
    avoidIdeaId?: string,
  ): Promise<SelectedIdea> {
    if (!this.initialized) {
      throw new Error("ChallengeCycleStore must be initialized before use.");
    }

    const operation = this.queue.then(() =>
      this.selectAndPersist(guildId, categoryId, avoidIdeaId),
    );
    this.queue = operation.then(
      () => undefined,
      () => undefined,
    );
    return operation;
  }

  private async selectAndPersist(
    guildId: string,
    categoryId?: ChallengeCategoryId,
    avoidIdeaId?: string,
  ): Promise<SelectedIdea> {
    const nextCycles: StoredCycles = Object.fromEntries(
      Object.entries(this.cycles).map(([id, state]) => [
        id,
        { ...state, remaining: [...state.remaining] },
      ]),
    );

    let guildCycle = nextCycles[guildId];
    if (!guildCycle) {
      guildCycle = {
        remaining: shuffledIdeaIds(),
        ideaBankVersion: currentIdeaBankVersion,
      };
      nextCycles[guildId] = guildCycle;
    }

    if (guildCycle.remaining.length === 0) {
      guildCycle.remaining = shuffledIdeaIds();
    }

    let candidates = categoryId
      ? guildCycle.remaining.filter(
          (id) => ideasById.get(id)?.category === categoryId,
        )
      : guildCycle.remaining;

    if (categoryId && candidates.length === 0) {
      throw new NoIdeasInCategoryError(categoryId);
    }

    if (candidates.length === 0) {
      guildCycle.remaining = shuffledIdeaIds();
      candidates = guildCycle.remaining;
    }

    if (avoidIdeaId && candidates.length > 1) {
      const alternatives = candidates.filter((id) => id !== avoidIdeaId);
      if (alternatives.length > 0) candidates = alternatives;
    }

    const selectedId = candidates[randomInt(candidates.length)];
    if (!selectedId) {
      throw new Error("No drawing ideas are available.");
    }

    const selectedIndex = guildCycle.remaining.indexOf(selectedId);
    guildCycle.remaining.splice(selectedIndex, 1);
    await this.persist(nextCycles);
    this.cycles = nextCycles;

    const selected = ideasById.get(selectedId);
    if (!selected) {
      throw new Error(`Selected drawing idea ${selectedId} does not exist.`);
    }

    return {
      id: selected.id,
      prompt: selected.prompt,
      category: selected.category,
    };
  }

  private async persist(cycles: StoredCycles): Promise<void> {
    const temporaryFile = `${this.statePath}.tmp`;
    await writeFile(temporaryFile, JSON.stringify(cycles, null, 2), "utf8");
    await rename(temporaryFile, this.statePath);
  }
}