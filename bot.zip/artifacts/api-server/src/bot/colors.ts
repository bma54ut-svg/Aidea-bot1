import { randomInt } from "node:crypto";

export interface PaletteColor {
  name: string;
  hex: string;
}

export const paletteColors: PaletteColor[] = [
  { name: "أزرق سماوي", hex: "#68B7E3" },
  { name: "أزرق ليلي", hex: "#23395B" },
  { name: "تركواز", hex: "#39B7A7" },
  { name: "نيلي", hex: "#483D8B" },
  { name: "أزرق ملكي", hex: "#2F66C8" },
  { name: "بنفسجي غامق", hex: "#6C3FA0" },
  { name: "لافندر", hex: "#B69CFF" },
  { name: "فوشيا", hex: "#EA4C89" },
  { name: "وردي غباري", hex: "#D98FA3" },
  { name: "أحمر قرمزي", hex: "#B83240" },
  { name: "مرجاني", hex: "#F26B5B" },
  { name: "برتقالي محروق", hex: "#C96A2B" },
  { name: "مشمشي", hex: "#FFB26B" },
  { name: "أصفر ذهبي", hex: "#E8B923" },
  { name: "أصفر ليموني", hex: "#DCE85C" },
  { name: "أخضر زمردي", hex: "#168C68" },
  { name: "أخضر نعناعي", hex: "#86D6A5" },
  { name: "أخضر زيتوني", hex: "#828B3A" },
  { name: "أخضر غابة", hex: "#285943" },
  { name: "بني كستنائي", hex: "#845334" },
  { name: "بني كراميل", hex: "#BA7C4B" },
  { name: "عاجي", hex: "#F4E7CE" },
  { name: "رمادي ضبابي", hex: "#A9B2BD" },
  { name: "فحمي", hex: "#30343B" },
  { name: "أسود داكن", hex: "#1F2024" },
  { name: "أبيض قمري", hex: "#F8F7F1" },
  { name: "ذهبي", hex: "#D2A548" },
  { name: "فضي", hex: "#AEB7C2" },
  { name: "أزرق ثلجي", hex: "#B5D7E9" },
  { name: "أرجواني ليلي", hex: "#53224F" },
  { name: "أحمر طوبي", hex: "#A64936" },
  { name: "أخضر بحري", hex: "#247C83" },
  { name: "عنابي", hex: "#702F46" },
  { name: "ليلكي", hex: "#A77BC8" },
  { name: "أصفر خردلي", hex: "#C89B28" },
  { name: "أخضر تفاحي", hex: "#9ACD50" },
  { name: "أزرق محيطي", hex: "#176B87" },
  { name: "أزرق نيلي فاتح", hex: "#6C91BF" },
  { name: "أخضر مريمي", hex: "#A3B18A" },
  { name: "أخضر صباري", hex: "#6F8F72" },
  { name: "أحمر طماطمي", hex: "#D94F3D" },
  { name: "وردي خوخي", hex: "#F2A7A0" },
  { name: "بنفسجي برقوقي", hex: "#704264" },
  { name: "أصفر زبدي", hex: "#F3D77A" },
  { name: "بني رملي", hex: "#C2A47E" },
  { name: "رمادي أردوازي", hex: "#65737E" },
  { name: "أزرق ضبابي", hex: "#91B5C8" },
  { name: "نحاسي", hex: "#B56B45" },
  { name: "أخضر ليموني", hex: "#B7C94B" },
  { name: "أحمر وردي", hex: "#C95C75" },
  { name: "بنفسجي ثلجي", hex: "#C9B6E4" },
  { name: "بني جوزي", hex: "#654321" },
  { name: "أزرق بترولي", hex: "#176D74" },
];

export function choosePalette(count: number): PaletteColor[] {
  if (!Number.isInteger(count) || count < 1 || count > paletteColors.length) {
    throw new RangeError("The requested palette size is not available.");
  }

  const available = [...paletteColors];
  const selected: PaletteColor[] = [];

  for (let index = 0; index < count; index += 1) {
    const chosenIndex = randomInt(available.length);
    selected.push(available.splice(chosenIndex, 1)[0]!);
  }

  return selected;
}