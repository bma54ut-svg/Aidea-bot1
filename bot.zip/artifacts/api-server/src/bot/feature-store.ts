import { randomUUID } from "node:crypto";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import type { ChallengeCategoryId } from "./ideas";

export type IdeaVote = "up" | "down";

export interface VoteCounts {
  up: number;
  down: number;
  removed: boolean;
}

export interface CommunityIdea {
  id: string;
  prompt: string;
  category: ChallengeCategoryId;
}

export interface IdeaSuggestion extends CommunityIdea {
  authorId: string;
  submittedAt: string;
  status: "pending" | "approved" | "rejected";
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface DailyChallengeConfig {
  channelId: string;
  time: string;
  timeZone: string;
  enabled: boolean;
  lastAttemptDate?: string;
  lastPostedDate?: string;
  messageId?: string;
  threadId?: string;
}

interface GuildFeatureState {
  suggestions: IdeaSuggestion[];
  daily: DailyChallengeConfig | null;
}

interface StoredFeatureState {
  version: 1;
  guilds: Record<string, GuildFeatureState>;
  votes: Record<string, Record<string, IdeaVote>>;
  removedIdeaIds: string[];
}

export interface DailyChallengeSchedule {
  guildId: string;
  config: DailyChallengeConfig;
}

export interface ReviewResult {
  suggestion: IdeaSuggestion;
  communityIdea?: CommunityIdea;
}

export const ideaRemovalDownvoteThreshold = 10;

const defaultStatePath = process.env["DATA_DIR"]
  ? resolve(process.env["DATA_DIR"], "bot-features.json")
  : resolve(dirname(fileURLToPath(import.meta.url)), "../data/bot-features.json");

function emptyState(): StoredFeatureState {
  return {
    version: 1,
    guilds: {},
    votes: {},
    removedIdeaIds: [],
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function validateSuggestion(value: unknown): value is IdeaSuggestion {
  if (!isRecord(value)) return false;
  return (
    typeof value.id === "string" &&
    typeof value.prompt === "string" &&
    typeof value.category === "string" &&
    typeof value.authorId === "string" &&
    typeof value.submittedAt === "string" &&
    (value.status === "pending" ||
      value.status === "approved" ||
      value.status === "rejected") &&
    (value.reviewedBy === undefined || typeof value.reviewedBy === "string") &&
    (value.reviewedAt === undefined || typeof value.reviewedAt === "string")
  );
}

function validateDailyConfig(value: unknown): value is DailyChallengeConfig {
  if (!isRecord(value)) return false;
  return (
    typeof value.channelId === "string" &&
    /^\d{2}:\d{2}$/.test(String(value.time)) &&
    typeof value.timeZone === "string" &&
    typeof value.enabled === "boolean" &&
    (value.lastAttemptDate === undefined ||
      typeof value.lastAttemptDate === "string") &&
    (value.lastPostedDate === undefined ||
      typeof value.lastPostedDate === "string") &&
    (value.messageId === undefined || typeof value.messageId === "string") &&
    (value.threadId === undefined || typeof value.threadId === "string")
  );
}

function parseState(value: unknown): StoredFeatureState {
  if (
    !isRecord(value) ||
    value.version !== 1 ||
    !isRecord(value.guilds) ||
    !isRecord(value.votes) ||
    !Array.isArray(value.removedIdeaIds) ||
    !value.removedIdeaIds.every((id) => typeof id === "string")
  ) {
    throw new Error("Bot feature state file is invalid.");
  }

  const guilds: Record<string, GuildFeatureState> = {};
  for (const [guildId, rawGuild] of Object.entries(value.guilds)) {
    if (
      !isRecord(rawGuild) ||
      !Array.isArray(rawGuild.suggestions) ||
      !rawGuild.suggestions.every(validateSuggestion) ||
      (rawGuild.daily !== null && !validateDailyConfig(rawGuild.daily))
    ) {
      throw new Error(`Bot feature state is invalid for guild ${guildId}.`);
    }
    guilds[guildId] = {
      suggestions: rawGuild.suggestions,
      daily: rawGuild.daily,
    };
  }

  const votes: StoredFeatureState["votes"] = {};
  for (const [ideaId, rawVotes] of Object.entries(value.votes)) {
    if (
      !isRecord(rawVotes) ||
      !Object.values(rawVotes).every(
        (vote) => vote === "up" || vote === "down",
      )
    ) {
      throw new Error(`Bot vote state is invalid for idea ${ideaId}.`);
    }
    votes[ideaId] = rawVotes as Record<string, IdeaVote>;
  }

  return {
    version: 1,
    guilds,
    votes,
    removedIdeaIds: value.removedIdeaIds,
  };
}

function toCommunityIdea(suggestion: IdeaSuggestion): CommunityIdea {
  const prompt = suggestion.prompt
    .replace(/^ارسم\s*[:،-]?\s*/u, "")
    .trim();
  return {
    id: `community-${suggestion.id}`,
    prompt: `ارسم: ${prompt}`,
    category: suggestion.category,
  };
}

function getOrCreateGuild(
  state: StoredFeatureState,
  guildId: string,
): GuildFeatureState {
  state.guilds[guildId] ??= { suggestions: [], daily: null };
  return state.guilds[guildId]!;
}

export class BotFeatureStore {
  private state = emptyState();
  private initialized = false;
  private queue: Promise<void> = Promise.resolve();

  constructor(private readonly statePath = defaultStatePath) {}

  async initialize(): Promise<void> {
    await mkdir(dirname(this.statePath), { recursive: true });
    try {
      this.state = parseState(JSON.parse(await readFile(this.statePath, "utf8")));
    } catch (error) {
      if (
        typeof error === "object" &&
        error !== null &&
        "code" in error &&
        error.code === "ENOENT"
      ) {
        this.state = emptyState();
      } else {
        throw error;
      }
    }
    this.initialized = true;
  }

  async submitIdea(
    guildId: string,
    prompt: string,
    category: ChallengeCategoryId,
    authorId: string,
  ): Promise<IdeaSuggestion> {
    const normalizedPrompt = prompt.trim().replace(/\s+/gu, " ");
    if (normalizedPrompt.length < 10 || normalizedPrompt.length > 300) {
      throw new RangeError("Idea suggestions must contain 10 to 300 characters.");
    }

    return this.mutate((next) => {
      const guild = getOrCreateGuild(next, guildId);
      const pendingCount = guild.suggestions.filter(
        ({ status }) => status === "pending",
      ).length;
      if (pendingCount >= 200) {
        throw new Error("This server has too many ideas waiting for review.");
      }

      const suggestion: IdeaSuggestion = {
        id: randomUUID(),
        prompt: normalizedPrompt,
        category,
        authorId,
        submittedAt: new Date().toISOString(),
        status: "pending",
      };
      guild.suggestions.push(suggestion);
      return structuredClone(suggestion);
    });
  }

  listPendingIdeas(guildId: string, limit = 5): IdeaSuggestion[] {
    this.assertInitialized();
    return (this.state.guilds[guildId]?.suggestions ?? [])
      .filter(({ status }) => status === "pending")
      .slice(0, limit)
      .map((suggestion) => structuredClone(suggestion));
  }

  async reviewIdea(
    guildId: string,
    suggestionId: string,
    approve: boolean,
    reviewerId: string,
  ): Promise<ReviewResult> {
    return this.mutate((next) => {
      const guild = getOrCreateGuild(next, guildId);
      const suggestion = guild.suggestions.find(
        ({ id }) => id === suggestionId,
      );
      if (!suggestion) throw new Error("The idea suggestion was not found.");
      if (suggestion.status !== "pending") {
        throw new Error("This idea suggestion has already been reviewed.");
      }

      suggestion.status = approve ? "approved" : "rejected";
      suggestion.reviewedBy = reviewerId;
      suggestion.reviewedAt = new Date().toISOString();

      return {
        suggestion: structuredClone(suggestion),
        ...(approve ? { communityIdea: toCommunityIdea(suggestion) } : {}),
      };
    });
  }

  getApprovedIdeas(guildId: string): CommunityIdea[] {
    this.assertInitialized();
    return (this.state.guilds[guildId]?.suggestions ?? [])
      .filter(({ status }) => status === "approved")
      .map(toCommunityIdea);
  }

  getAllApprovedIdeas(): CommunityIdea[] {
    this.assertInitialized();
    return Object.keys(this.state.guilds).flatMap((guildId) =>
      this.getApprovedIdeas(guildId),
    );
  }

  async castVote(
    ideaId: string,
    userId: string,
    vote: IdeaVote,
  ): Promise<VoteCounts> {
    return this.mutate((next) => {
      const existing = next.votes[ideaId]?.[userId];
      if (!next.removedIdeaIds.includes(ideaId)) {
        if (existing === vote) {
          delete next.votes[ideaId]?.[userId];
        } else {
          next.votes[ideaId] ??= {};
          next.votes[ideaId]![userId] = vote;
        }
      }

      const votes = Object.values(next.votes[ideaId] ?? {});
      const up = votes.filter((value) => value === "up").length;
      const down = votes.filter((value) => value === "down").length;
      if (
        down >= ideaRemovalDownvoteThreshold &&
        !next.removedIdeaIds.includes(ideaId)
      ) {
        next.removedIdeaIds.push(ideaId);
      }

      return {
        up,
        down,
        removed: next.removedIdeaIds.includes(ideaId),
      };
    });
  }

  getVoteCounts(ideaId: string): VoteCounts {
    this.assertInitialized();
    const votes = Object.values(this.state.votes[ideaId] ?? {});
    return {
      up: votes.filter((vote) => vote === "up").length,
      down: votes.filter((vote) => vote === "down").length,
      removed: this.state.removedIdeaIds.includes(ideaId),
    };
  }

  getRemovedIdeaIds(): ReadonlySet<string> {
    this.assertInitialized();
    return new Set(this.state.removedIdeaIds);
  }

  async configureDaily(
    guildId: string,
    config: Pick<DailyChallengeConfig, "channelId" | "time" | "timeZone">,
  ): Promise<void> {
    if (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(config.time)) {
      throw new RangeError("Daily challenge time must use HH:mm format.");
    }
    return this.mutate((next) => {
      const guild = getOrCreateGuild(next, guildId);
      guild.daily = {
        ...guild.daily,
        ...config,
        enabled: true,
      };
    });
  }

  async disableDaily(guildId: string): Promise<void> {
    return this.mutate((next) => {
      const guild = getOrCreateGuild(next, guildId);
      if (guild.daily) guild.daily.enabled = false;
    });
  }

  getDailyConfig(guildId: string): DailyChallengeConfig | undefined {
    this.assertInitialized();
    const config = this.state.guilds[guildId]?.daily;
    return config ? structuredClone(config) : undefined;
  }

  getDailySchedules(): DailyChallengeSchedule[] {
    this.assertInitialized();
    return Object.entries(this.state.guilds).flatMap(([guildId, guild]) =>
      guild.daily?.enabled
        ? [{ guildId, config: structuredClone(guild.daily) }]
        : [],
    );
  }

  async claimDailyPost(guildId: string, date: string): Promise<boolean> {
    this.assertInitialized();
    const daily = this.state.guilds[guildId]?.daily;
    // Do not consume today's run until the Discord message is actually posted.
    // This makes transient Discord/API failures retry on the next scheduler tick.
    return Boolean(daily?.enabled && daily.lastPostedDate !== date);
  }

  async recordDailyPost(
    guildId: string,
    date: string,
    messageId: string,
    threadId?: string,
  ): Promise<void> {
    return this.mutate((next) => {
      const daily = getOrCreateGuild(next, guildId).daily;
      if (!daily) throw new Error("Daily challenge is not configured.");
      daily.lastAttemptDate = date;
      daily.lastPostedDate = date;
      daily.messageId = messageId;
      daily.threadId = threadId;
    });
  }

  private mutate<T>(change: (next: StoredFeatureState) => T): Promise<T> {
    this.assertInitialized();
    const operation = this.queue.then(async () => {
      const next = structuredClone(this.state);
      const result = change(next);
      const temporaryPath = `${this.statePath}.${process.pid}.tmp`;
      await writeFile(temporaryPath, JSON.stringify(next, null, 2), "utf8");
      await rename(temporaryPath, this.statePath);
      this.state = next;
      return result;
    });
    this.queue = operation.then(
      () => undefined,
      () => undefined,
    );
    return operation;
  }

  private assertInitialized(): void {
    if (!this.initialized) {
      throw new Error("BotFeatureStore must be initialized before use.");
    }
  }
}