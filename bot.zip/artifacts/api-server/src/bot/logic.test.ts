import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { choosePalette, paletteColors } from "./colors";
import {
  ChallengeCycleStore,
  currentIdeaBankVersion,
  NoIdeasInCategoryError,
} from "./challenge-cycle";
import {
  characterTraitDefinitions,
  createCharacterProfile,
} from "./character-generator";
import {
  BotFeatureStore,
  ideaRemovalDownvoteThreshold,
} from "./feature-store";
import { challengeCategories, drawingIdeas } from "./ideas";
import { poseReferences } from "./poses";
import { parseNamedArguments, parsePrefixCommand } from "./command-parser";

async function withTemporaryState(
  run: (stateFile: string) => Promise<void>,
): Promise<void> {
  const directory = await mkdtemp(join(tmpdir(), "aidea-cycle-test-"));
  try {
    await run(join(directory, "challenge-cycles.json"));
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
}

test("the idea bank is large, categorized, and free of duplicate prompts", () => {
  assert.equal(drawingIdeas.length, 1500);
  assert.ok(drawingIdeas.length % 10 === 0);
  assert.ok(challengeCategories.length + 1 <= 25);

  const validCategories = new Set(challengeCategories.map(({ id }) => id));
  const ideasPerCategory = new Map<string, number>();
  for (const idea of drawingIdeas) {
    ideasPerCategory.set(
      idea.category,
      (ideasPerCategory.get(idea.category) ?? 0) + 1,
    );
  }
  const ids = new Set(drawingIdeas.map(({ id }) => id));
  const prompts = new Set(
    drawingIdeas.map(({ prompt }) => prompt.trim().normalize("NFC")),
  );

  assert.equal(ids.size, drawingIdeas.length);
  assert.equal(prompts.size, drawingIdeas.length);
  assert.ok(drawingIdeas.every(({ category }) => validCategories.has(category)));
  assert.ok(
    challengeCategories.every(
      ({ id }) => (ideasPerCategory.get(id) ?? 0) >= 40,
    ),
  );
  assert.ok(drawingIdeas.every(({ prompt }) => prompt.startsWith("ارسم: ")));
  assert.deepEqual(
    drawingIdeas.slice(0, 470).map(({ id }) => id),
    Array.from({ length: 470 }, (_, index) =>
      `idea-${String(index + 1).padStart(3, "0")}`,
    ),
  );
  assert.ok(
    challengeCategories.every(({ id }) =>
      drawingIdeas.some((idea) => idea.category === id),
    ),
  );
  assert.equal(
    drawingIdeas.filter(({ category }) => category === "fantasy").length,
    116,
  );
  assert.deepEqual(
    drawingIdeas.slice(700, 750).map(({ id }) => id),
    Array.from({ length: 50 }, (_, index) =>
      `idea-${String(index + 701).padStart(3, "0")}`,
    ),
  );
  assert.ok(
    drawingIdeas
      .slice(700, 750)
      .every(({ category }) => category === "fantasy"),
  );
  assert.deepEqual(
    drawingIdeas.slice(830).map(({ id }) => id),
    Array.from({ length: 670 }, (_, index) =>
      `idea-${String(index + 831).padStart(3, "0")}`,
    ),
  );
  assert.ok(drawingIdeas.every(({ prompt }) => !/[A-Za-z]/.test(prompt)));
  assert.ok(drawingIdeas[240]!.prompt.includes("فلكي"));
  assert.ok(!drawingIdeas[240]!.prompt.includes("فعشان"));
  assert.ok(drawingIdeas[0]!.prompt.includes("تطالع"));
  assert.ok(drawingIdeas[0]!.prompt.includes("شباك"));
  assert.deepEqual(Object.fromEntries(ideasPerCategory), {
    animals: 95,
    creative: 91,
    everyday: 91,
    nature: 95,
    city: 92,
    travel: 92,
    culture: 95,
    community: 92,
    science: 92,
    stories: 92,
    fantasy: 116,
    food: 91,
    objects: 91,
    vehicles: 92,
    architecture: 91,
    art: 92,
  });
});

test("palette selection returns distinct named colors and valid sizes", () => {
  assert.equal(
    new Set(paletteColors.map(({ hex }) => hex.toLowerCase())).size,
    paletteColors.length,
  );
  assert.equal(
    new Set(paletteColors.map(({ name }) => name)).size,
    paletteColors.length,
  );

  for (const count of [2, 3, 4]) {
    const palette = choosePalette(count);
    assert.equal(palette.length, count);
    assert.equal(
      new Set(palette.map(({ hex }) => hex.toLowerCase())).size,
      count,
    );
  }
  assert.throws(() => choosePalette(0), RangeError);
  assert.throws(() => choosePalette(paletteColors.length + 1), RangeError);
});

test("character generation fills every feature and respects selected options", () => {
  const profile = createCharacterProfile({
    hair: "كيرلي كثيف",
    hair_color: "أزرق لامع",
  });

  assert.equal(Object.keys(profile).length, characterTraitDefinitions.length);
  assert.equal(profile.hair, "كيرلي كثيف");
  assert.equal(profile.hair_color, "أزرق لامع");
  assert.ok(!("pose" in profile));
  const removedTraitIds = new Set([
    "pose",
    "species",
    "age_impression",
    "role",
    "personality",
    "silhouette",
    "material",
    "story_hook",
  ]);
  assert.ok(
    characterTraitDefinitions.every(({ id }) => !removedTraitIds.has(id)),
  );
  assert.ok(
    characterTraitDefinitions.every((trait) =>
      trait.choices.some((choice) => choice === profile[trait.id]),
    ),
  );
});

test("character trait options are varied and unique; outfit options are paginated for Discord", () => {
  for (const trait of characterTraitDefinitions) {
    assert.equal(
      new Set(trait.choices).size,
      trait.choices.length,
      `${trait.label} should not contain duplicate options`,
    );
    assert.ok(
      trait.choices.length >= 15,
      `${trait.label} should offer a broad range of choices`,
    );
    if (trait.id === "outfit") {
      assert.equal(trait.choices.length, 132);
    } else {
      assert.ok(
        trait.choices.length <= 25,
        `${trait.label} exceeds Discord's 25-choice limit`,
      );
    }
  }
});

test("each illustrated pose has a valid reference image and drawing guidance", async () => {
  assert.equal(poseReferences.length, 132);
  assert.equal(
    new Set(poseReferences.map(({ id }) => id)).size,
    poseReferences.length,
  );
  assert.equal(
    new Set(poseReferences.map(({ label }) => label)).size,
    poseReferences.length,
  );
  const assetDirectory =
    process.cwd().endsWith("api-server")
      ? join(process.cwd(), "assets", "poses")
      : join(process.cwd(), "artifacts", "api-server", "assets", "poses");
  for (const pose of poseReferences) {
    assert.ok(pose.description.length > 50);
    assert.ok(pose.drawingTip.length > 10);
    assert.ok((await stat(join(assetDirectory, pose.imageFile))).size > 0);
  }
});

test("community suggestions, moderation, voting, and daily schedules persist", async () => {
  await withTemporaryState(async (stateFile) => {
    const store = new BotFeatureStore(stateFile);
    await store.initialize();

    const submitted = await store.submitIdea(
      "community-guild",
      "  ارسم   سوقاً   ليلياً   فوق السحاب  ",
      "community",
      "artist-1",
    );
    assert.equal(submitted.prompt, "ارسم سوقاً ليلياً فوق السحاب");
    assert.equal(store.listPendingIdeas("community-guild", 1)[0]?.id, submitted.id);

    const approved = await store.reviewIdea(
      "community-guild",
      submitted.id,
      true,
      "moderator",
    );
    assert.equal(
      approved.communityIdea?.prompt,
      "ارسم: سوقاً ليلياً فوق السحاب",
    );
    const approvedIdeaId = approved.communityIdea!.id;
    assert.equal(store.getApprovedIdeas("community-guild").length, 1);

    const rejected = await store.submitIdea(
      "community-guild",
      "ارسم روبوتاً يزرع حديقة صغيرة",
      "science",
      "artist-2",
    );
    await store.reviewIdea(
      "community-guild",
      rejected.id,
      false,
      "moderator",
    );
    assert.deepEqual(
      store.getApprovedIdeas("community-guild").map(({ id }) => id),
      [approvedIdeaId],
    );

    for (let index = 0; index < ideaRemovalDownvoteThreshold; index += 1) {
      await store.castVote(approvedIdeaId, `voter-${index}`, "down");
    }
    assert.deepEqual(store.getVoteCounts(approvedIdeaId), {
      up: 0,
      down: ideaRemovalDownvoteThreshold,
      removed: true,
    });

    await store.configureDaily("community-guild", {
      channelId: "drawing-channel",
      time: "18:30",
      timeZone: "Asia/Baghdad",
    });
    assert.equal(await store.claimDailyPost("community-guild", "2026-10-02"), true);
    assert.equal(await store.claimDailyPost("community-guild", "2026-10-02"), false);
    await store.recordDailyPost(
      "community-guild",
      "2026-10-02",
      "challenge-message",
    );

    const restartedStore = new BotFeatureStore(stateFile);
    await restartedStore.initialize();
    assert.equal(
      restartedStore.getDailyConfig("community-guild")?.lastPostedDate,
      "2026-10-02",
    );
    assert.equal(restartedStore.getApprovedIdeas("community-guild").length, 1);
    assert.equal(restartedStore.getVoteCounts(approvedIdeaId).removed, true);

    await restartedStore.disableDaily("community-guild");
    assert.deepEqual(restartedStore.getDailySchedules(), []);
  });
});

test("cycle selection serializes concurrent requests and survives restart", async () => {
  await withTemporaryState(async (stateFile) => {
    const store = new ChallengeCycleStore(stateFile);
    await store.initialize();

    const firstBatch = await Promise.all(
      Array.from({ length: 80 }, () => store.next("test-guild")),
    );
    assert.equal(
      new Set(firstBatch.map(({ id }) => id)).size,
      firstBatch.length,
    );

    const fantasyBatch = await Promise.all(
      Array.from({ length: 20 }, () => store.next("fantasy-guild", "fantasy")),
    );
    assert.ok(fantasyBatch.every(({ category }) => category === "fantasy"));
    assert.equal(
      new Set(fantasyBatch.map(({ id }) => id)).size,
      fantasyBatch.length,
    );

    const restartedStore = new ChallengeCycleStore(stateFile);
    await restartedStore.initialize();
    const secondBatch = await Promise.all(
      Array.from({ length: 15 }, () => restartedStore.next("test-guild")),
    );
    const firstBatchIds = new Set(firstBatch.map(({ id }) => id));
    assert.ok(secondBatch.every(({ id }) => !firstBatchIds.has(id)));

    const savedState = JSON.parse(await readFile(stateFile, "utf8")) as Record<
      string,
      { remaining: string[] }
    >;
    assert.ok(Array.isArray(savedState["test-guild"]?.remaining));
  });
});

test("a depleted category returns a clear domain error instead of looping", async () => {
  await withTemporaryState(async (stateFile) => {
    const remaining = drawingIdeas
      .filter(({ category }) => category !== "animals")
      .map(({ id }) => id);
    await writeFile(
      stateFile,
      JSON.stringify({
        "test-guild": { remaining, ideaBankVersion: currentIdeaBankVersion },
      }),
      "utf8",
    );

    const store = new ChallengeCycleStore(stateFile);
    await store.initialize();
    await assert.rejects(
      store.next("test-guild", "animals"),
      NoIdeasInCategoryError,
    );
  });
});

test("a replacement idea avoids the previous idea when a cycle refills", async () => {
  await withTemporaryState(async (stateFile) => {
    const onlyRemainingIdea = drawingIdeas[0]!.id;
    await writeFile(
      stateFile,
      JSON.stringify({
        "test-guild": {
          remaining: [onlyRemainingIdea],
          ideaBankVersion: currentIdeaBankVersion,
        },
      }),
      "utf8",
    );

    const store = new ChallengeCycleStore(stateFile);
    await store.initialize();
    const previous = await store.next("test-guild");
    const replacement = await store.next(
      "test-guild",
      undefined,
      previous.id,
    );

    assert.equal(previous.id, onlyRemainingIdea);
    assert.notEqual(replacement.id, previous.id);
  });
});

test("saved cycles containing the original idea IDs remain readable", async () => {
  await withTemporaryState(async (stateFile) => {
    await writeFile(
      stateFile,
      JSON.stringify({
        "legacy-guild": { remaining: ["idea-001", "idea-270"] },
      }),
      "utf8",
    );

    const store = new ChallengeCycleStore(stateFile);
    await store.initialize();
    const selected = await store.next("legacy-guild");
    const savedState = JSON.parse(await readFile(stateFile, "utf8")) as Record<
      string,
      { remaining: string[] }
    >;
    const preservedIds = new Set([
      selected.id,
      ...savedState["legacy-guild"]!.remaining,
    ]);
    assert.ok(["idea-001", "idea-270"].every((id) => preservedIds.has(id)));
  });
});

test("older saved cycles receive new ideas once without losing remaining ideas", async () => {
  await withTemporaryState(async (stateFile) => {
    const legacyIds = ["idea-001", "idea-270"];
    await writeFile(
      stateFile,
      JSON.stringify({ "legacy-guild": { remaining: legacyIds } }),
      "utf8",
    );

    const store = new ChallengeCycleStore(stateFile);
    await store.initialize();
    const first = await store.next("legacy-guild", "community");
    assert.equal(first.category, "community");

    const savedAfterMigration = JSON.parse(
      await readFile(stateFile, "utf8"),
    ) as Record<
      string,
      { remaining: string[]; ideaBankVersion: number }
    >;
    const firstRemaining = savedAfterMigration["legacy-guild"]!.remaining;
    const newIdeaIds = drawingIdeas.slice(470).map(({ id }) => id);

    assert.equal(
      savedAfterMigration["legacy-guild"]!.ideaBankVersion,
      currentIdeaBankVersion,
    );
    assert.equal(
      newIdeaIds.filter((id) => firstRemaining.includes(id)).length,
      newIdeaIds.length - 1,
    );
    assert.ok(legacyIds.every((id) => firstRemaining.includes(id)));

    const restartedStore = new ChallengeCycleStore(stateFile);
    await restartedStore.initialize();
    const second = await restartedStore.next("legacy-guild", "community");

    assert.notEqual(second.id, first.id);
    assert.equal(second.category, "community");
  });
});

test("version 2 saved cycles receive every later idea once", async () => {
  await withTemporaryState(async (stateFile) => {
    const oldRemainingIds = ["idea-001", "idea-700"];
    await writeFile(
      stateFile,
      JSON.stringify({
        "legacy-guild": {
          remaining: oldRemainingIds,
          ideaBankVersion: 2,
        },
      }),
      "utf8",
    );

    const store = new ChallengeCycleStore(stateFile);
    await store.initialize();
    const first = await store.next("legacy-guild", "fantasy");
    assert.equal(first.category, "fantasy");

    const laterIds = drawingIdeas.slice(700).map(({ id }) => id);
    assert.ok(
      drawingIdeas
        .filter(({ category }) => category === "fantasy")
        .some(({ id }) => id === first.id),
    );

    const saved = JSON.parse(await readFile(stateFile, "utf8")) as Record<
      string,
      { remaining: string[]; ideaBankVersion: number }
    >;
    const migrated = saved["legacy-guild"]!;
    assert.equal(migrated.ideaBankVersion, currentIdeaBankVersion);
    assert.ok(oldRemainingIds.every((id) => migrated.remaining.includes(id)));
    assert.equal(
      laterIds.filter((id) => migrated.remaining.includes(id)).length,
      laterIds.length - 1,
    );

    const restartedStore = new ChallengeCycleStore(stateFile);
    await restartedStore.initialize();
    const second = await restartedStore.next("legacy-guild", "fantasy");
    assert.notEqual(second.id, first.id);
  });
});

test("prefix commands use an asterisk and ignore slash commands", () => {
  assert.deepEqual(parsePrefixCommand("  *CHALLENGE theme=animals"), {
    command: "challenge",
    argumentText: "theme=animals",
  });
  assert.equal(parsePrefixCommand("/challenge"), undefined);
  assert.equal(parsePrefixCommand("*"), undefined);
});

test("named command arguments preserve quoted values and free text", () => {
  assert.deepEqual(
    parseNamedArguments('hair_color="أزرق غامق" theme=animals prompt="فكرة طويلة"'),
    {
      options: {
        hair_color: "أزرق غامق",
        theme: "animals",
        prompt: "فكرة طويلة",
      },
      positionalText: "",
    },
  );
  assert.deepEqual(parseNamedArguments("colors ارسم قطة"), {
    options: {},
    positionalText: "colors ارسم قطة",
  });
});