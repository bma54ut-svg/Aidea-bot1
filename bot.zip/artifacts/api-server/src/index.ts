import app from "./app";
import { logger } from "./lib/logger";
import { startDiscordBot } from "./bot/discord-bot";
import { keepAlive } from "./keepAlive";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

keepAlive(app);

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  const botToken = process.env["DISCORD_BOT_TOKEN"];
  if (!botToken) {
    if (process.env["NODE_ENV"] === "production") {
      logger.fatal("DISCORD_BOT_TOKEN is required to run the bot in production");
      process.exit(1);
    }
    logger.warn("DISCORD_BOT_TOKEN is missing; the Discord bot was not started");
    return;
  }

  void startDiscordBot(botToken).catch((error: unknown) => {
    logger.fatal({ err: error }, "Discord bot startup failed");
    process.exit(1);
  });
});
