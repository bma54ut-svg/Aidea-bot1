import { spawnSync } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";

const artifactDirectory = path.dirname(fileURLToPath(import.meta.url));
const temporaryDirectory = await mkdtemp(
  path.join(os.tmpdir(), "aidea-tests-"),
);
const bundledTests = path.join(temporaryDirectory, "logic.test.mjs");

try {
  await build({
    entryPoints: [path.join(artifactDirectory, "src/bot/logic.test.ts")],
    outfile: bundledTests,
    bundle: true,
    platform: "node",
    format: "esm",
    packages: "external",
    logLevel: "silent",
  });

  const result = spawnSync(process.execPath, ["--test", bundledTests], {
    stdio: "inherit",
  });
  if (result.error) throw result.error;
  process.exitCode = result.status ?? 1;
} finally {
  await rm(temporaryDirectory, { recursive: true, force: true });
}