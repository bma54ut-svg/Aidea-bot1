# Aidea Discord Bot

بوت ديسكورد عربي لتحديات الرسم، وتكوين الشخصيات، ومراجع البوزات، واقتراحات المجتمع والتحديات اليومية.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — تشغيل واجهة الصحة والبوت
- `pnpm --filter @workspace/api-server run test` — تشغيل اختبارات منطق البوت
- `pnpm --filter @workspace/api-server run typecheck` — فحص أنواع خادم البوت
- `pnpm run typecheck` — فحص جميع الحزم
- السر المطلوب: `DISCORD_BOT_TOKEN` — أضِفه عبر Replit Secrets، ولا تضعه في الشيفرة أو المحادثة.
- مسار الصحة: `/api/healthz`
- حذف أوامر Discord القديمة اختياري: `CLEAR_LEGACY_SLASH_COMMANDS=true`. الافتراضي هو الاحتفاظ بها.

## Stack

- pnpm workspaces، Node.js 24، TypeScript 5.9
- API وفحص الصحة: Express 5
- بوت ديسكورد: discord.js 14
- البناء: esbuild

## Where things live

- `artifacts/api-server/src/bot/` — أوامر البوت ومنطق التحديات
- `artifacts/api-server/assets/poses/` — صور مراجع البوزات
- `artifacts/api-server/data/` — حالة دورات الأفكار واقتراحات المجتمع
- `artifacts/api-server/src/index.ts` — تشغيل خادم الصحة والبوت

## Product

- أوامر بادئة النجمة مثل `*challenge` و`*form` و`*poses` و`*help`
- تحديات رسم قابلة للتخصيص، دون تكرار الأفكار داخل دورة السيرفر
- تكوين شخصيات بتفاصيل الرسم والملابس
- معرض مستقل لمراجع البوزات من أمر `*poses`
- اقتراحات المجتمع والتصويت والمراجعة الإدارية وجدولة تحديات يومية

## Discord setup

- فعّل **Message Content Intent** من Discord Developer Portal → Bot → Privileged Gateway Intents.
- ادعُ البوت بصلاحيات عرض القنوات، وإرسال الرسائل، وإرفاق الملفات، وتضمين الروابط.
- أوامر حذف أوامر Discord القديمة لا تعمل إلا بعد ضبط `CLEAR_LEGACY_SLASH_COMMANDS=true`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
